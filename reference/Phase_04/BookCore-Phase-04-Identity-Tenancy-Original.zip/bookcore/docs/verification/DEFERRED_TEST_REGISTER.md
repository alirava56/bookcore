# BookCore — Deferred Verification Register, Phase04 update

The original Phase 02/03 obligations are **not waived**. They are summarized with Phase 04 additions below. Every item is `NOT VERIFIED` until real evidence exists.

| ID | Requirement / Risk | Related source | Test or probe | Environment | Evidence now | Acceptance criterion | Status |
|---|---|---|---|---|---|---|---|
| P2-G1 | Real PG migrations and checksums | db/migrations/001–005 | npm run migrate twice | PG17, npm | unavailable | both runs successful, checksums equal | NOT VERIFIED |
| P2-G2 | DB tenant and row integrity | db/migrations/001–004 | reference Phase02 PG tests | PG17 | code only | invalid SQL rejected | NOT VERIFIED |
| P2-G3 | 100 concurrent capacity 1/20 | Phase02 spike harness | 3× two processes each | PG17 / two processes | code only | exactly 1/20 committed, no workers leaked | NOT VERIFIED |
| P2-G4 | GiST resource exclusion | migrations 001–004 | reference Phase02 tests | PG17 | code only | overlap rejected, adjacent accepted | NOT VERIFIED |
| P2-G5 | Booking Idempotency & unknown outcome | Phase02 spike | Phase02 tests | PG17 | code only | 1 effect per key | NOT VERIFIED |
| P2-G6 | Booking/session cancellation atomicity | Phase02 spike | Phase02 tests | PG17 | code only | full 15-seat commit or rollback | NOT VERIFIED |
| P2-G7 | Committed-state counter drift | migrations 001–004 | Phase02 negative SQL | PG17 | code only | invalid writes rejected | NOT VERIFIED |
| P2-G8 | Clean npm install / reproducibility | package.json | npm ci | npm Registry | ENOTCACHED, no lockfile | clean install, typecheck, tests pass | NOT VERIFIED |
| P3-A | NestJS Bootstrap runtime | app.module.ts, bootstrap.ts | HTTP unit tests | npm Registry | TS AST | /live 200, /ready 503 when DB unready | NOT VERIFIED |
| P4-01 | Global APP_GUARD default deny | common/security, app.module | global-auth.test.ts + anonymous HTTP | npm Registry | source only | absent token 401 | NOT VERIFIED |
| P4-02 | Argon2id normalized registration | identity.service + 005 | PG registration/duplicate tests | npm + PG17 | source only | no plaintext, unique | NOT VERIFIED |
| P4-03 | JWT signature/expiry/aud/kid | token.service | jwt.test.ts | npm | source only | invalid claims rejected | NOT VERIFIED |
| P4-04 | Refresh replay race | identity.service + 005 | two Promise.all refresh | npm + PG17 | source only | one child maximum, replay revokes | NOT VERIFIED |
| P4-05 | Concurrent role and last Owner protection | organizations + 005 | real concurrent PATCH | npm + PG17 | source only | last active OWNER remains | NOT VERIFIED |
| P4-06 | Cross-tenant and privilege negative SQL | authorization + 005 | RBAC integration tests | npm + PG17 | source only | foreign 404, direct DML restricted | NOT VERIFIED |
| P4-07 | Reproducible implemented OpenAPI | scripts/generate-openapi.ts | npm run openapi:current | npm | source only | 12 routes, no future paths | NOT VERIFIED |
| P4-08 | Auth secrets/limit security under load | Argon2 / rate-limit guard | soak, brute/DoS | staging PG17 | none | bounded memory/latency | NOT VERIFIED |
| P4-09 | Refresh lost COMMIT UX | identity.service and UoW | fault injection | PG17 / proxy | none | recovery semantics agreed and verified | NOT VERIFIED |

**Release constraint:** Production release is blocked until Phase 02 gates, Phase04 critical auth/token/tenant gates, and cleanroom CI are demonstrably passing. Development deferral is not a release waiver.
