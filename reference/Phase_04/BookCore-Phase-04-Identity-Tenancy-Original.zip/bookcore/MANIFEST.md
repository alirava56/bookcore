# BookCore Phase 04 — Delivery Manifest

**Status:** source implementation candidate, runtime tests deferred. Original Phase 03 archive preserved byte-for-byte as `reference/Phase_03/BookCore-Phase-03-Backend-Foundation.zip`.

## Primary deliverables and roles

- `apps/api/src/`: NestJS application source, global fail-closed security, Identity and Organizations modules.
- `apps/api/test/`: 39 test declarations in source (unexecuted against Nest/PostgreSQL in this environment).
- `db/migrations/001–004`: unchanged historical migrations. `005_identity_security.sql`: additive Phase04 migration.
- `docs/`: domain/design, Phase04 ADR, authentication and RBAC policy, API contract, audit and verification reports.
- `.github/workflows/backend-phase04.yml`: CI definition; **not run**.
- `scripts/`: migrations, implemented-only Swagger generator, test runner, static checks.
- `infra/docker/`: PostgreSQL17/API/migration service and Dockerfile; not tested here.
- `evidence/phase04/`: observed AST/static checks and blocked npm/runtime command logs.
- `reference/Phase_02/` and `reference/Phase_03/`: unmodified legacy source archives and provenance.
- `package.json`: selected dependencies and scripts; **no fabricated package-lock.json**, npm Registry unavailable.
- `docs/engineering/PHASE_04_FINAL_REPORT_FA.md`: final Persian engineering findings.

## SHA-256 inventory

The manifest lists every packaged project file other than this self-referential `MANIFEST.md`.
All entries are relative to `bookcore/` inside the ZIP. `SHA-256` is over raw uncompressed file bytes.

| Relative path | SHA-256 | Bytes |
|---|---|---:|
| `.dockerignore` | `53a07051b93a242500d993a259d3fec8f858664a1835758f5284dfaf8b211825` | 78 |
| `.env.example` | `753926c4158811d46cac2f1b3a2b9b0d55dc1258ef679370a8e9c7599320cc93` | 1236 |
| `.github/workflows/backend-phase04.yml` | `0b90b52fb064645044d0b537f5dd5d67aeb125e66bdf54638f28f628be62c7cc` | 2762 |
| `.gitignore` | `591ba6a7b0e292716174bc1e4b5b98eab7cebfe4bcfd576e75fb2fb823efd435` | 84 |
| `.prettierrc.json` | `673f7eb35df241be018376a802510f823debcb35aff3f8fbb3efcd892c228d95` | 60 |
| `README.md` | `476ffb525dddeac7d47c8df88fa0ad8e1455373dd017be0ee33c36d752a57e42` | 3756 |
| `apps/api/src/app.module.ts` | `271c393742847aed1116c94f2aaa2c5bffc03f19bf58c133db066dc0b97a9a1e` | 1076 |
| `apps/api/src/bootstrap.ts` | `c1a2a63271716bf275ef6ee303f508ab440838c2e65ce9d4c254f17b9c3c4c3b` | 3047 |
| `apps/api/src/common/errors/problem.filter.ts` | `b7d94f9e08646a90ff880748b36d75e23cfc72fc42a7c60e80dee541f82a4c7f` | 1292 |
| `apps/api/src/common/errors/problem.ts` | `d1e19e4e1f6d8afc87c748431b7ab8961ed6ec63ea5d7aaaea6862df06eac908` | 1788 |
| `apps/api/src/common/logging/json-logger.ts` | `711d842157ba4859815d066b249c79a8ae3e3528c258e6fb7e01e2566e415b78` | 1480 |
| `apps/api/src/common/observability/request-context.ts` | `8483e1be67e6b111511e13dcfd3f028231f8ed031cfb31acca69a03361003a77` | 475 |
| `apps/api/src/common/security/authorization.ts` | `b7394219f03c7407d1cb5d83a98cca972be9e3f71494b0173ce1b363117e4276` | 2576 |
| `apps/api/src/common/security/monitor.guard.ts` | `6f94e40d00ad77e973b2ba72d44b84e73b0f4f9e0cceb8fdd26c70f2d263fc49` | 1561 |
| `apps/api/src/common/security/principal.ts` | `b9156f1e4abf50f253435d1454069c6f476f7b6a761b9aa6ecc18c9959f8650f` | 475 |
| `apps/api/src/common/security/rate-limit.guard.ts` | `52159dbe8dacf818b1138923c33e77e1d33f720dd11d06aea89321924c13ea4d` | 1859 |
| `apps/api/src/config/app-config.ts` | `817392351d6ee98d021bf496b86ba01dacf444a5d73edf68fe62d74283fe530c` | 5929 |
| `apps/api/src/infrastructure/database/database.module.ts` | `d887e7693f1af1e5ccf8d0f2910ef09ae44bd855014fc8e21ed80cfcd8b1d89d` | 407 |
| `apps/api/src/infrastructure/database/database.service.ts` | `42328eef3d4d27e3fa6894c5efdbf7db1f86fe602f4cfd72c937821e3bf80747` | 2158 |
| `apps/api/src/infrastructure/database/migration-checksums.ts` | `a3cc3dfb7154eeecffc12b71a0c5a71e970b779804cc1358dc836b0cca8d7213` | 622 |
| `apps/api/src/infrastructure/transactions/sqlstate.ts` | `9e5511e032798e4e795a99e34e70c9756f311e544ac2cafb498abf0e939709c6` | 1041 |
| `apps/api/src/infrastructure/transactions/unit-of-work.ts` | `be615a17c0d70c9f967dda646917510332c34bcbb31fff6b6a856eedb2101dcf` | 2337 |
| `apps/api/src/main.ts` | `2935dfee8ae095be2cbe02332c402f9a81e07c7da0d1786e83417ad058790d59` | 556 |
| `apps/api/src/modules/booking/booking-sql.adapter.ts` | `0112adc75e25eab49b8dbe76ef6161fc13de06045c58783ec27fbc503727c148` | 1247 |
| `apps/api/src/modules/health/health.controller.ts` | `2d2feb009fe5e56e715ace088b708fe67a92716a62acc433c10da3eeec65888b` | 1428 |
| `apps/api/src/modules/health/health.module.ts` | `ab3a87d2f1d28197d942fc01eeed588e5793eda9fa2ea09b5096a4c8b23d8d57` | 261 |
| `apps/api/src/modules/identity/identity.controller.ts` | `26c4accc1602537d80d56ff46bc9b7a9c2f8d6fd2d9bca51dae6b8630b7e711d` | 1698 |
| `apps/api/src/modules/identity/identity.dto.ts` | `d7fe06fbb8acb1a634655e6f860007b34cbc7bc127573b9830e208d771d608b7` | 1698 |
| `apps/api/src/modules/identity/identity.module.ts` | `673ecffb5618c99046baf2d42a211f0e530e83000b03699f83befbf32bcb40a6` | 446 |
| `apps/api/src/modules/identity/identity.service.ts` | `c5a909ea716849bf3b6c1798bdbd8590b5e3c1fdd44522d06aec145c55273c1b` | 7717 |
| `apps/api/src/modules/identity/token.service.ts` | `62fc477a0554f4fa384ab7e74d2c759de17b6f3f95fc74388af4ca36cbb6e698` | 1881 |
| `apps/api/src/modules/organizations/authorization.service.ts` | `6f6d08dc2e9d9ba592d76c7d7a68453faa9032fab072ecb87ede743cdac37c9c` | 2635 |
| `apps/api/src/modules/organizations/organization.dto.ts` | `341ba80331bbe212b96e984575251d3d838f27526579c2f3c35cf8ede7e67fd7` | 2099 |
| `apps/api/src/modules/organizations/organizations.controller.ts` | `8fc52413ee5f767e581cd4ffab85819fed62dbe0d26bd0a82d4eda1ee53bfd21` | 2330 |
| `apps/api/src/modules/organizations/organizations.module.ts` | `0ac89703db2e2d183dc86aba2ecda3ec61bb7df866a5e88dba88a3d394453fd5` | 421 |
| `apps/api/src/modules/organizations/organizations.service.ts` | `d598ce7ffa11b8c79d94890f02669d0aab960f6886cb2032282abd3d17f703ed` | 8724 |
| `apps/api/test/integration/identity-tenant-postgres.test.ts` | `0f47f22083eccaad0bf9e3709aef3aca2cf21bd0595c37353b4737f27cf96aad` | 10717 |
| `apps/api/test/integration/postgres.test.ts` | `e784848d4177063e27ba9aa73ba5ad9f742a775e18d2ff4651dbc8f5d9913843` | 1097 |
| `apps/api/test/test-auth.ts` | `0002015c450c90cd04bc647f45647a1fe71e3d91a6c2484e1b8a48bbba3ead49` | 398 |
| `apps/api/test/unit/config.test.ts` | `de2053c0748c8969094d2243de51706b0555eb7f06295572e407fe7e87e77836` | 1887 |
| `apps/api/test/unit/database-ready.test.ts` | `847b04fd334fc94e0ecda56f3dc942ee24abbfa163851413681793b87b7ecb12` | 1298 |
| `apps/api/test/unit/errors.test.ts` | `3f2a38fab82e0675c757214a8e16b09ad8c7de4c009b120aee13bf40b2791264` | 1185 |
| `apps/api/test/unit/global-auth.test.ts` | `1e3f53122f0eeccb780dcf77c0b153963a1d736cca4f0f6ac5c3b2106123af5a` | 2342 |
| `apps/api/test/unit/http.test.ts` | `dcfd18b27c41bf701647e67dcb0e5092ec9bf130ccb11a93f860393a3af0994e` | 2300 |
| `apps/api/test/unit/jwt.test.ts` | `4d270478b722c372d6de7fe9067599b6f4f2cbf3d8d87fd3718701de3b90c5d7` | 3108 |
| `apps/api/test/unit/phase04-policy.test.ts` | `e8e936ed3040482450e263718cb590ae3e44451fa2735a3d7bacf18c9253d4b8` | 2730 |
| `apps/api/test/unit/security.test.ts` | `687e6dd27622291374b1e381fa5d44537d74baab32e4ff16d57a9a37af2c1fa2` | 1573 |
| `apps/api/test/unit/transaction.test.ts` | `09de19b99518afeabdb8103197e97b388414ba09f962aa95fd3888f047a58997` | 2963 |
| `apps/api/test/unit/validation.test.ts` | `4154690200b669f428416988697ac3916c2f03534eb482705f749cc30869455c` | 816 |
| `db/migrations/001_core.sql` | `d83fdc0165aca2ad451a8aeeabaa13b24419632b1bebd1e84ad8705552c17454` | 14611 |
| `db/migrations/002_resource_guard.sql` | `ca330e5e009baed904384724304658aeef578bd4d1a04c53067b0a8c7e0fc728` | 767 |
| `db/migrations/003_hardening.sql` | `ec225d749b25eb6372e0723318f2553a1774876f4138761353ffec7653835798` | 7979 |
| `db/migrations/004_history_consistency.sql` | `4a5bb3c92384d8aa9e71e2822ce74d4bc0c31e12be6fbf04ea4879ddb77b89dd` | 9026 |
| `db/migrations/005_identity_security.sql` | `16634916fc696eac599a0d459ee35952f8649cf77a1300c58baaea95e73921fd` | 5985 |
| `docs/api/PHASE_04_API_CONTRACT.md` | `450fd5e4a2b3d56979f651036ae00bc44e231309a89842f2971e91cd03fa5e3c` | 2640 |
| `docs/api/openapi.yaml` | `0d3d93416dbd72e6e92b6903f96478623c8e0f5b3a27c65eec169263e7d3dffa` | 90120 |
| `docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | 1290 |
| `docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | 1557 |
| `docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | 1378 |
| `docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | 1408 |
| `docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | 2256 |
| `docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | 997 |
| `docs/architecture/ADR/ADR-020-PHASE03-FOUNDATION-AND-DEFERRED-RUNTIME.md` | `18bdec44006c71f901533b038baf23812a8983772626470ea27d5641297721fc` | 1932 |
| `docs/architecture/ADR/ADR-021-PHASE04-IDENTITY-TENANCY.md` | `45624973c31afea4a5c3bf7368897c94124d21613af3b9790982c19eeeeea48f` | 1888 |
| `docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | 908 |
| `docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | 16417 |
| `docs/architecture/BACKEND_STRUCTURE_FA.md` | `b11e5b4a75beabb7141d7176785784a31ce78240d7ac365ed6b7d36b048c207a` | 3393 |
| `docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | 19033 |
| `docs/database/DATABASE_INTEGRATION_FA.md` | `44777741f162c35ff8dd50e2b0c2c727adc103e4b80bc7fca376e4df38757fea` | 3852 |
| `docs/database/PHASE_04_MIGRATIONS_FA.md` | `364787ac91d1481f9909f6a2ad5dd09e1d0d8d99fd2907d5255a6657491fc052` | 2364 |
| `docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | 11946 |
| `docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | 7400 |
| `docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | 9126 |
| `docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | 6247 |
| `docs/engineering/PHASE04_INDEPENDENT_SOURCE_AUDIT_FA.md` | `5275d578cc3906dbc65849ae4a4dd1bf36d2a413a49aafe0c7248aff55105f65` | 3909 |
| `docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | 18928 |
| `docs/engineering/PHASE_03_FINAL_REPORT_FA.md` | `0f730045a9b2233d01c65d1f25caa11e03dcca0d0ebeb46114f8427b939f6f37` | 8741 |
| `docs/engineering/PHASE_04_FINAL_REPORT_FA.md` | `bb8555481d02fd6629c33bf1788adea7d6698f5426ce490b3de5ebbed8a6332e` | 8066 |
| `docs/identity/IDENTITY_DESIGN_FA.md` | `59b37e29cdad6c81f1114dac7cf89566275bb788dafdc2b8070a21f7dd13dd06` | 3497 |
| `docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | 10032 |
| `docs/security/AUTHENTICATION_SECURITY_FA.md` | `2a17a0231e4941a326bafd56f1960046cf2710a5beed7a924205891c10be78cf` | 5236 |
| `docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | 10271 |
| `docs/security/RBAC_TENANT_ISOLATION_FA.md` | `51d0f59e25e866242640d9b0f19c1a040bf3c0111727ebde43663c2c0dff3851` | 2728 |
| `docs/security/SECURITY_FOUNDATION_FA.md` | `7ddf83b9fabcbbf4d319a974a23ea10aca09b8802d322357ef0d12f12226ac63` | 2683 |
| `docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | 8109 |
| `docs/verification/DEFERRED_TEST_REGISTER.md` | `6cbda3d5b27759c6a93947e87c7303c9a14e1624d040fbea3c92002a511873ba` | 3492 |
| `docs/verification/PHASE_03_CHECKLIST.md` | `b9fe5e7667b10f66f31e4a171f0719299f6f4a17631ff69d02b665e85f30ff79` | 1812 |
| `docs/verification/PHASE_03_TEST_EVIDENCE.md` | `8f00353a13a5a76b925093d6c78ac65034afb0b1ca0320b6bcbfecb7c265d322` | 2958 |
| `docs/verification/PHASE_03_WORKFLOW_REFERENCE.yml` | `19c6c624cbab176ead4d88654746d90c6334741c6a811faaccd3a95afb1f1de5` | 2454 |
| `docs/verification/PHASE_04_TEST_MATRIX.md` | `b697347d8f6d8a3d44d848f08938934f81d43b43c5625d0488bd14f08346886e` | 1733 |
| `docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | 14829 |
| `docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | 4303 |
| `eslint.config.mjs` | `d0b78e46807452fb689d313734f0ca018b81db979f012f9dd5bec7b6294a5103` | 383 |
| `evidence/build_attempt.log` | `704aa72a16456b6b3e2e343daeabb5677bf081909a2a4d70f5a6dd33b718e1f2` | 11795 |
| `evidence/build_attempt_final.log` | `f4204bd57e3e7d9242672db482bfd91e4fb0e6c4cfe20335caa2857b38561b95` | 11795 |
| `evidence/ci_yaml_parse.log` | `df5980d827fef941242b47d3f7812ae0633bb8b9a7319d331a7db65fbf85f47a` | 184 |
| `evidence/lint_attempt.log` | `6c053306829fe7ce88401dc7f9c5b89167a2eb741607dd4362a9acfe6948760c` | 140 |
| `evidence/node_npm_environment.log` | `4b3712a53279f7056a98c312e264214c9fe6e0300330015001494de79c4e19af` | 76 |
| `evidence/noemit_check.log` | `2a72072f07b92705bb156968105797774041f46e57d00b37c1b87133d111e277` | 70 |
| `evidence/npm_ci_attempt.log` | `2e62d799b46f4f569d88dd4dcd049f6d2110d1257ee0cef8448170957df679b4` | 1192 |
| `evidence/npm_lockfile_attempt.log` | `edf1f733d89d0573aa2d64869ec1e52323765b876f67c1c4a3c992422bfa013a` | 53 |
| `evidence/phase01_yaml_parse.log` | `e5fe9057a12c7ce98870bb759c3194ee3878af38882ed7ba985c4122106ddc49` | 53 |
| `evidence/phase02_migration_provenance.log` | `cd9964887f9a0456ef0e22637e989cb06326130a0d12b7dc1c5cd752ccdfc34e` | 462 |
| `evidence/phase03_test_summary.json` | `d142c8018fb44a9eb4dbb02cc4599c82e22f0d1ff7b9eecf2fb16df52373dc6f` | 1890 |
| `evidence/phase04/build_attempt.log` | `ed24ad9d3915fdd1ffd3579b288f97233670839aa6f58fa8fb1f312b833105f7` | 19657 |
| `evidence/phase04/cleanroom_verification.log` | `07a80fe6b80d5850d75a47beadde75aa0e9e1a8372716d778c0f2b3180d5a21f` | 868 |
| `evidence/phase04/contract_check.log` | `9b2a6f2feb995708dead1be43612246d5fd9a01ebbca7ae7597076d9119f00e0` | 96 |
| `evidence/phase04/environment.log` | `813584481aa2f3b18510db45a330ce9abb88a36852298f71b6b3fbe2c1d29b12` | 54 |
| `evidence/phase04/invariant_audit.log` | `fa1c01e7aa8b395dc9be98c016619ab7c419b678088c4908e81435c8a7348b01` | 88 |
| `evidence/phase04/lint_attempt.log` | `4d8674d0d1a8d944ec5e198d9f146ef8c7dacb9b8840de254d40afd90946c57b` | 129 |
| `evidence/phase04/migration_checksum_check.log` | `e94e08ebec22e576fea986f59a918c0ba87b8a73e88748ff5473383f27a03d5e` | 54 |
| `evidence/phase04/npm_ci_attempt.log` | `6c09261cd796def43c88becd3a4c544bbda27596a42e671f0f3ce6f1ab1fc364` | 1185 |
| `evidence/phase04/npm_lockfile_attempt.log` | `c43806ab852e0b6cf3c4df132dfb2a142ae8708e088628817b345ff81290639c` | 279 |
| `evidence/phase04/npm_registry_ping.log` | `2dae4355a7bc09a8823144c13d82ed923759ec0edb315b1eb9eb320fdfe403c2` | 349 |
| `evidence/phase04/reference_check.log` | `1c91bf987cb0aaa9f126afe707c93022a8932a2f426aa5715f6899e2b9656324` | 103 |
| `evidence/phase04/static_source.log` | `5c366377cc6577c3e1410f6f786eed0f12e3a61fc360e9df4e74c71332965b91` | 94 |
| `evidence/phase04/syntax_scan.log` | `9af51b6dc698def12bc382992eb058ca79a50fae73ece36dc9478fb3675b8e1e` | 30 |
| `evidence/phase04/test-summary.json` | `2814f89ba27ebefe9ae3ff64e850c0bbd0b0f11f2e78d5fc1996e0d423935f0d` | 3051 |
| `evidence/phase04/test_unit_attempt.log` | `20ae93b3ab51ba243b46f3315f937934f9fdb8c527ec2ecb58daf46870d05258` | 192 |
| `evidence/phase04/typecheck_attempt.log` | `4e7a923e9236edf7dd130bb250d76ba350d15eb766262c5a41953cb4a885f9dc` | 19670 |
| `evidence/phase04/zero_runner.log` | `dcc173967cd177a1dfc7930e6dfd5bdb3e92421c74268bf483c3238a9a15da85` | 64 |
| `evidence/reference_check.log` | `1c91bf987cb0aaa9f126afe707c93022a8932a2f426aa5715f6899e2b9656324` | 103 |
| `evidence/static_check.log` | `689fedf22e6d06316d6cc580ecb108c5a0a3138e427f06844e9c94a9e8a9d4d7` | 76 |
| `evidence/typecheck_attempt.log` | `1459dfbccaecd001fd258a7e97d0af463ee6155709303fabe21c59ee9f1d577d` | 11808 |
| `evidence/typescript_syntax.log` | `e88e5925c3e5ac1bf1d7d78fbee1bac0b2373bc9eadbbe51a102a631d1ea3d47` | 62 |
| `evidence/unit_test_attempt.log` | `56fa08260d618b9c8a0c70ae14cbfe634b4755b519bc513d1f1730fc68939bf6` | 119 |
| `evidence/zero_test_runner_selftest.log` | `afa24c8233b713441b8b1f10e65604082e0ebedb3ec0196ffc6d6b8b806389f4` | 73 |
| `evidence/zero_tests_guard.log` | `311ed8b9006fe9e9c4aaa67b8495fcb34d47839b509a85c0415d2bc2abd7a29e` | 130 |
| `infra/docker/Dockerfile` | `87fa586f34da967e150c9b29ecca09dee9988e5d888e9186b5f88b9f6896ab39` | 596 |
| `infra/docker/compose.yml` | `9d0f5ad66931ab8806fd19da8b4fdb778e10c85fe78788944287708a79cdb34b` | 2300 |
| `infra/docker/init-db.sh` | `d87a4a4591b250252b7826d7ba6a3b36cc279a1f8e79a974d1eca0a22c6986df` | 343 |
| `package.json` | `c918bc9aae1fb58f8ad0f28fe77dfbb6ca101f5c138291155efdb3270fe1509a` | 1704 |
| `reference/Phase_02/BookCore-Phase-02-Technical-Spike-Final-Verified.zip` | `3da3f894ff4a55c20ef3ff1ae666169c1461f6fb7f0230dee55be8a22e8efcab` | 696320 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/.github/workflows/postgres-spike.yml` | `5a3c8e5cc9f2d0f3b7229a66efb57e7782db47f7c94284d76d2460eb4ba010e3` | 2374 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/infra/docker-compose.yml` | `bb9f4f343b3da743e97bb447b057cba14d75684c001e9193ed1542bd08a2e706` | 520 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/BOOKCORE_SOFTWARE_ENGINEERING_BLUEPRINT_FA.md` | `3eb10bbc6a2679db4f70b7ef574369a2bf8b315b9585cb3b504ed4cf46609da5` | 61655 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/MANIFEST.md` | `e2b3da9791463bff793c58d3bc981f3d99ea2d317afba4f2388c8b5f3e6a9b2e` | 5572 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/README.md` | `091f74f733f66949f74bfae1fb2c71f511870f8859503286b87d790ac8ab896d` | 2017 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/api/openapi.yaml` | `5f28b246a01ee6b733c53f70c32eef09383e8013f5f11b75b040288b170f5f6b` | 90120 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | 1290 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | 1557 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | 1378 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | 1408 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | 2256 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | 997 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | 908 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | 16417 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | 19033 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | 11946 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | 7400 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | 9126 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | 6247 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | 18928 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | 10032 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | 10271 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | 8109 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | 14829 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | 4303 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/tools/validate_phase01.py` | `4baaf52f3bccd006c6623322695252b850bdc205f3d51c62b0b1425a46e9af2b` | 19841 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/.env.example` | `85f7ba4de1c53d4607f30e801898679aab818cdcfc7776c2cde9b8d139dd2b61` | 226 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/001_core.sql` | `d83fdc0165aca2ad451a8aeeabaa13b24419632b1bebd1e84ad8705552c17454` | 14611 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/002_resource_guard.sql` | `ca330e5e009baed904384724304658aeef578bd4d1a04c53067b0a8c7e0fc728` | 767 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/003_hardening.sql` | `ec225d749b25eb6372e0723318f2553a1774876f4138761353ffec7653835798` | 7979 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/004_history_consistency.sql` | `4a5bb3c92384d8aa9e71e2822ce74d4bc0c31e12be6fbf04ea4879ddb77b89dd` | 9026 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/package.json` | `a6dd8f6577b5584e21f346fbf61292b91e3f69ec11193dde1b897b2a09b8ac6d` | 839 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/db.ts` | `6b05b15d831e56693864a62a68d47c8ec3c37553e46c9dd7c5a94ccf35146fe0` | 3697 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/fixtures.ts` | `11e60843f7e7a319fc1025fbdac7a91cb25bc75c6595a093009d90c1ee288e9a` | 5715 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/migrate.ts` | `a0fd5aa1bfcf44b9d2d2870df2593a06c780598f0f1f302b38e75336efa27976` | 1698 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/operations.ts` | `c4e1f0b2a5e5270be7b3c7729b7a205785f94d8dc29383658bf3625606b96824` | 13456 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/reconcile.ts` | `427e906498bff25b055868a9ad2700703be47283d2fdcc06d5bc746005007780` | 3794 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/worker.ts` | `f9cf9e44aaa9954041e36ec1b9d7826e61b9a0769f207ef401a12a8dfe6d0e8b` | 1824 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/tests/spike.test.ts` | `6a37c0705b8db8f220911401855ab7a334446b5b3f06a51d9f3511a6e547f793` | 37322 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/tsconfig.json` | `19d6366451313279b4509584c3f599e11f7474533872a99c6d9c0f34ebd14f0d` | 407 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/package_phase02.py` | `a5b1b4b5772dc59f143e5438aa7539d5268af7b197807d0965c4d442b1f4d83d` | 3503 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/package_verified.py` | `77803f867dfe99c1dcb5853981ad0e48833d4f58907f40ab142686af7e8a7f79` | 3492 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/run-local.sh` | `75b0802ea2681d9ddb4403433ad72dd7bc94db3d03e65df23929aad50c302d45` | 698 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/run_tests.mjs` | `6ca275b50d0d4e8b767a5df39c06c808def073688509750a7fb45c81ab9471fa` | 4225 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/static_checks.mjs` | `6add3a94a741968165bc698774ac05856b17ffaed4d0a7cc0a07f2dc37af503b` | 4264 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/verify_package.py` | `0e34f3b614082348ed27995731c3b39d7f98012f542c96da9b469b3828b2064e` | 1273 |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/verify_reference.py` | `81d1c927b796f9c5e0c1b370884e0e0f6ba1af6aa810e7da5b92d16b1f8d8d29` | 739 |
| `reference/Phase_03/BookCore-Phase-03-Backend-Foundation.zip` | `a9302346fbee90d52bbe96e45406b02137c1287e751cec6f14a1f2ee5f8906a2` | 1000394 |
| `scripts/check-clean-archive.cjs` | `dee3aa09ed1529db1271f737d98b0dcb8680dcb08a4a6ea35e0d81c913fa3582` | 478 |
| `scripts/generate-openapi.ts` | `334a18f7f0c19336660a633b1e79ffd0d8a6c5b74eeb7aa1851bddf9833fe028` | 1412 |
| `scripts/migrate.ts` | `5cef95564e6e27ac305950aa28145272c0a6b066921e61bc57f1c7d2b092aa0e` | 2486 |
| `scripts/phase04-source-audit.cjs` | `52988ecc0afb9bf743e1ed0b63b07d2ce1728b5d44b135566b85bd72da8505b2` | 2121 |
| `scripts/phase04_contract_check.py` | `4c343c1ca4d67ecdebfd5a907738a3cc3f20f35ffc9a2efe2a4744ed37a7cfd5` | 2113 |
| `scripts/run-tests.cjs` | `22fc2fc834de489f8e3d888e9b59726f644a438540cbb2a9b0ea155d7a34653d` | 2089 |
| `scripts/selftest-zero-runner.cjs` | `7c4987b96aaec54dff57b485ac9c703f40f52bf5023322650a3a906d28b2ecb8` | 2375 |
| `scripts/static-verify.cjs` | `b629de662034e2577e9b97a638ad85ba37cb05678a2cd26a4e992f4800d02d41` | 2036 |
| `scripts/verify-manifest.cjs` | `d3f8b06abc0b1dda14188197955f115358e1c26b7fb41bb2ee623fcebcc87730` | 1279 |
| `scripts/verify-migration-checksums.cjs` | `12075fe51a3ad845c49de2668797401dfce34f88b17e2add2bff539396c85467` | 558 |
| `scripts/verify-reference.cjs` | `7d954a55b2bc0268bc3c28a79961c797da873d9ca784ef59b3327beb87bd9c16` | 506 |
| `tsconfig.json` | `76eec1035bbbc7ca879b345f80f2ffc6126615db77a9f5bfabcb1bb4f397a6fb` | 684 |

**Files with recorded SHA-256:** 193. Manifest itself excluded to avoid recursive hashing.
