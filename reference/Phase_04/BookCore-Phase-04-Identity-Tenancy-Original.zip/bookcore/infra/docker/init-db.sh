#!/bin/sh
set -eu
# Runs only on the first initialization of a NEW development database.
: "${PG_DEV_APP_PASSWORD:?PG_DEV_APP_PASSWORD required}"
psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v app_password="$PG_DEV_APP_PASSWORD" <<'SQL'
SELECT format('CREATE ROLE bookcore_app LOGIN PASSWORD %L', :'app_password') \gexec
SQL
