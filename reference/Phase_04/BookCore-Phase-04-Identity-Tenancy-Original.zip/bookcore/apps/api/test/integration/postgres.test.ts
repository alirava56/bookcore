import test from 'node:test';
import assert from 'node:assert/strict';
import { Pool } from 'pg';

// This is an ACTUAL integration test: no mocks, never skipped. Requires schema migrated first.
test('PostgreSQL 17 and all five migration checksums are visible',async()=>{
 const url=process.env.DATABASE_URL;
 assert.ok(url,'DATABASE_URL is required for real PostgreSQL test');
 const pool=new Pool({connectionString:url,max:2,connectionTimeoutMillis:3000});
 try {
  const version=await pool.query<{server_version_num:string}>('SHOW server_version_num');
  assert.equal(version.rows[0]?.server_version_num.slice(0,2),'17');
  const schema=await pool.query<{present:boolean}>("SELECT to_regclass('public.sessions') IS NOT NULL AS present");
  assert.equal(schema.rows[0]?.present,true);
  const ledger=await pool.query<{name:string}>("SELECT name FROM bookcore_migrations ORDER BY name");
  assert.deepEqual(ledger.rows.map(r=>r.name),['001_core.sql','002_resource_guard.sql',
    '003_hardening.sql','004_history_consistency.sql','005_identity_security.sql']);
 } finally {await pool.end();}
});
