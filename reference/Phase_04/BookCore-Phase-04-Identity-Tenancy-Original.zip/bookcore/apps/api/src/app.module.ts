import {Module,Global,DynamicModule} from '@nestjs/common';
import {APP_GUARD} from '@nestjs/core';
import {AppConfigModule,type AppConfig} from './config/app-config';
import {DatabaseModule} from './infrastructure/database/database.module';
import {HealthModule} from './modules/health/health.module';
import {IdentityModule} from './modules/identity/identity.module';
import {OrganizationsModule} from './modules/organizations/organizations.module';
import {JsonLogger} from './common/logging/json-logger';
import {ProblemFilter} from './common/errors/problem.filter';
import {GlobalAuthGuard} from './common/security/authorization';
@Global()
@Module({imports:[IdentityModule],providers:[JsonLogger,ProblemFilter,
  {provide:APP_GUARD,useClass:GlobalAuthGuard}],exports:[JsonLogger,ProblemFilter]})
export class CommonModule {}
@Module({})
export class AppModule {
 static forRoot(config:AppConfig):DynamicModule {
  return {module:AppModule,imports:[AppConfigModule.register(config),DatabaseModule,
    IdentityModule,OrganizationsModule,CommonModule,HealthModule]};
 }
}
