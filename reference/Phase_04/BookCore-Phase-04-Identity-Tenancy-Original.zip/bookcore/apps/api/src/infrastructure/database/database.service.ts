import { Inject, Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool, type PoolClient } from 'pg';
import { APP_CONFIG, type AppConfig } from '../../config/app-config';
import {REQUIRED_MIGRATION_SHA256} from './migration-checksums';

@Injectable()
export class DatabaseService implements OnModuleDestroy {
  private readonly pool:Pool;
  constructor(@Inject(APP_CONFIG) private readonly config:AppConfig) {
    this.pool=new Pool({
      connectionString:config.databaseUrl,
      max:config.dbPoolMax,
      connectionTimeoutMillis:config.connectionTimeoutMs,
      idleTimeoutMillis:30000,
      application_name:'bookcore-api',
    });
    // A network error on an idle client otherwise becomes an unhandled EventEmitter error.
    this.pool.on('error',()=>{ /* no credentials or raw SQL in logs; readiness will fail */ });
  }
  async connect():Promise<PoolClient> { return this.pool.connect(); }
  async ready():Promise<boolean> {
    try {
      const expected=Object.entries(REQUIRED_MIGRATION_SHA256);
      const result=await this.pool.query<{name:string;checksum_sha256:string}>({
        text:`SELECT name,checksum_sha256 FROM bookcore_migrations WHERE name = ANY($1::text[])`,
        values:[expected.map(([name])=>name)],query_timeout:this.config.healthQueryTimeoutMs,
      });
      if(result.rows.length!==expected.length || result.rows.some(row=>
       REQUIRED_MIGRATION_SHA256[row.name]!==row.checksum_sha256))return false;
      const schema=await this.pool.query({text:`SELECT
       to_regclass('public.users') IS NOT NULL AS users_ok,
       to_regclass('public.auth_sessions') IS NOT NULL AS sessions_ok,
       to_regclass('public.refresh_tokens') IS NOT NULL AS refresh_ok,
       to_regclass('public.memberships') IS NOT NULL AS members_ok,
       to_regclass('public.password_credentials') IS NOT NULL AS credentials_ok`,
       query_timeout:this.config.healthQueryTimeoutMs});
      const r=schema.rows[0];
      return Boolean(r?.users_ok&&r?.sessions_ok&&r?.refresh_ok&&r?.members_ok&&r?.credentials_ok);
    } catch { return false; }
  }
  async onModuleDestroy():Promise<void> { await this.pool.end(); }
}
