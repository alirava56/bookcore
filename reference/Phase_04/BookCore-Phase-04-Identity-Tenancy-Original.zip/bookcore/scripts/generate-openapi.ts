import { writeFileSync } from 'node:fs';
import { DocumentBuilder,SwaggerModule } from '@nestjs/swagger';
import { buildApplication } from '../apps/api/src/bootstrap';

async function generate():Promise<void> {
  const app=await buildApplication();
  try {
    await app.init();
    const config=new DocumentBuilder().setTitle('BookCore Phase 04 implemented routes only')
      .setVersion('0.4.0').addBearerAuth().addApiKey({type:'apiKey',in:'header',name:'X-BookCore-Monitor-Key'},'monitorAuth').build();
    const document=SwaggerModule.createDocument(app,config);
    const output=process.env.OPENAPI_CURRENT_OUTPUT || 'docs/api/phase04-implemented.openapi.json';
    writeFileSync(output,JSON.stringify(document,null,2)+'\n');
    const paths=Object.keys(document.paths ?? {});
    const expected=['/api/v1/auth/register','/api/v1/auth/login','/api/v1/auth/refresh','/api/v1/auth/logout',
      '/api/v1/me','/api/v1/organizations','/api/v1/organizations/{orgId}',
      '/api/v1/organizations/{orgId}/members','/api/v1/organizations/{orgId}/members/{userId}',
      '/api/v1/health/live','/api/v1/health/ready'];
    if(paths.length!==expected.length || expected.some(path=>!paths.includes(path)))
      throw new Error('IMPLEMENTED_OPENAPI_ROUTE_MISMATCH');
  } finally { await app.close(); }
}
generate().catch(()=>{process.stderr.write('Implemented OpenAPI generation failed.\n');process.exitCode=1;});
