'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const base=process.cwd();
const rows=[...fs.readFileSync('MANIFEST.md','utf8').matchAll(/^\| `([^`]+)` \| `([a-f0-9]{64})` \| (\d+) \|/gm)];
assert.ok(rows.length>20,'manifest has too few entries');
const included=[];
for(const [,name,hash,size] of rows){
 const full=path.resolve(base,name);
 assert.ok(full.startsWith(base+path.sep),'unsafe manifest path');
 const file=fs.readFileSync(full);
 assert.equal(file.length,Number(size),`size mismatch: ${name}`);
 assert.equal(crypto.createHash('sha256').update(file).digest('hex'),hash,`hash mismatch: ${name}`);
 included.push(name);
}
const current=[];
function walk(dir,prefix=''){
 for(const de of fs.readdirSync(dir,{withFileTypes:true})){
  const rel=prefix?prefix+'/'+de.name:de.name;
  if(['node_modules','dist','.git'].includes(de.name)&&de.isDirectory()) continue;
  if(de.isDirectory())walk(path.join(dir,de.name),rel);
  else if(de.isFile()&&rel!=='MANIFEST.md')current.push(rel);
 }
}
walk(base);
assert.deepEqual(current.sort(),included.sort(),'files not fully represented by manifest');
console.log(`PASS MANIFEST: ${rows.length} files, all bytes/hashes and inventory matched`);
