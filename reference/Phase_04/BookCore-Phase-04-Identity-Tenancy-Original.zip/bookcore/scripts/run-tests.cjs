'use strict';
const fs=require('node:fs');
const path=require('node:path');
const cp=require('node:child_process');
const mode=process.argv[2];
if(!['unit','integration'].includes(mode)) {console.error('Usage: run-tests.cjs unit|integration');process.exit(2);}
const dir=path.join(process.cwd(),'dist','apps','api','test',mode);
if(!fs.existsSync(dir)) {console.error('FAIL: compiled test directory absent; build first:',dir);process.exit(2);}
const files=fs.readdirSync(dir).filter((f)=>f.endsWith('.test.js')).sort().map((f)=>path.join(dir,f));
if(files.length===0) {console.error('FAIL: zero test files');process.exit(2);}
const declarations=files.reduce((n,f)=>{
 const source=path.join(process.cwd(),'apps','api','test',mode,path.basename(f).replace(/\.js$/,'.ts'));
 if(!fs.existsSync(source))throw new Error('Missing original TypeScript test source: '+source);
 return n+(fs.readFileSync(source,'utf8').match(/\btest\s*\(/g)||[]).length;
},0);
if(!declarations) {console.error('FAIL: zero explicit tests');process.exit(2);}
const compiledCalls=files.reduce((n,f)=>(n+(fs.readFileSync(f,'utf8').match(/\b(?:test|node_test_\d+\.default)\s*\(|\(\s*0\s*,\s*node_test_\d+\.default\s*\)\s*\(/g)||[]).length),0);
if(compiledCalls<declarations){console.error('FAIL: compiled tests absent or fewer than declared source tests');process.exit(2);}
const result=cp.spawnSync(process.execPath,['--test','--test-reporter=tap',...files],
 {encoding:'utf8',timeout:900000,maxBuffer:20*1024*1024,env:process.env});
const output=(result.stdout||'')+(result.stderr||'');process.stdout.write(output);
const read=(label)=>{const all=[...output.matchAll(new RegExp('^# '+label+' (\\d+)\\s*$','gm'))];return all.length?Number(all.at(-1)[1]):-1;};
const count=read('tests'),failed=read('fail'),skipped=read('skipped'),passed=read('pass');
const ok=result.status===0&&!result.error&&count>=declarations&&passed>=declarations&&failed===0&&skipped===0;
console.log(JSON.stringify({mode,files:files.length,declarations,discovered:count,passed,failed,skipped,exit:result.status,ok}));
if(!ok)process.exitCode=1;
