# BookCore — Phase 05 Catalog, Resources & Availability Rules

**Implementation source candidate; NOT production-verified.** Preserves original Phase 01/02/03 engineering history. No Booking HTTP API, payment or waitlist added.

## Phase 05 changes

Existing Phase 05 Identity/Organizations stay intact. New protected CRUD: branches, services, resources, business-hours, schedule-exceptions (12 endpoints). Migration 006 is additive; no Session/Booking HTTP routes added. Pure availability returns rule-level decisions only; capacity and PostgreSQL GiST checks remain separate.

See `docs/scheduling/AVAILABILITY_RULES_FA.md` and `docs/security/PHASE_05_AUTHORIZATION_FA.md`.

## Implemented route surface
`/api/v1/health/live`, `/health/ready`, `/auth/register`, `/auth/login`, `/auth/refresh`, `/auth/logout`, `/me`, `/organizations`, `/organizations/:orgId`, `/organizations/:orgId/members`, `/organizations/:orgId/members/:userId` (GET/POST/PATCH as documented in `docs/api/PHASE_04_API_CONTRACT.md`).

## Operator prerequisites
Node 22.16+, npm access, PostgreSQL **17**, Docker Compose optional. **A genuine `package-lock.json` must be generated** by resolving dependencies. The current execution environment lacked usable registry access, so no fake lockfile is shipped. Authenticated CI cannot pass until this requirement is met.

### Clean-room commands
```bash
cd bookcore
# Generate REAL distinct secrets for local testing; never commit secrets to Git:
cp .env.example .env
# Set PG_DEV_OWNER_PASSWORD, PG_DEV_APP_PASSWORD, MONITOR_API_KEY,
# AUTH_JWT_KEYS_JSON, AUTH_JWT_ACTIVE_KID, AUTH_JWT_ISSUER, AUTH_JWT_AUDIENCE.
# Do not use placeholders in actual runs.
npm install --package-lock-only --ignore-scripts --no-audit
npm ci
npm run verify:reference && npm run verify:static
npm run test:availability:isolated # dependency-free real pure TS checks
npm run typecheck && npm run lint && npm run build
# PostgreSQL 17 must be running. app runtime role created before migration.
# Option A: use Postgres container:
docker compose -f infra/docker/compose.yml up -d postgres
# The postgres container init-db.sh provisions `bookcore_app` on first launch.
# Option B: provision the role yourself in test DB.
# Use MIGRATION_DATABASE_URL (owner credential) ONLY for migrations.
npm run migrate
npm run migrate # verifies the checksums
npm run test:unit
npm run test:integration
npm run openapi:current
# To start API with limited DATABASE_URL role:
npm run start
```

Environment variables are NOT automatically loaded by plain Node; provide variables via the shell, `docker compose --env-file`, or a local env launcher. If using Docker for migration:
```bash
docker compose --env-file .env -f infra/docker/compose.yml --profile maintenance run --rm migrate
docker compose --env-file .env -f infra/docker/compose.yml up -d api
```

`/health/live` is public. `/health/ready` is limited by direct peer IP + monitoring credential. The public auth endpoints have PostgreSQL rate limiting; all other routes use one global DB-backed JWT guard. `GET /me` includes only active staff memberships. Passwords are Argon2id hashes, refresh records store only SHA-256 verifiers.

## Deliverables and provenance
- `apps/api/src/modules/identity/` and `organizations/`: real source implementations.
- `db/migrations/001–004`: unchanged Phase02 originals. `005_identity_security.sql`: additive schema and role grants.
- `docs/api/openapi.yaml`: Phase 01 MVP design, not 38 implemented routes. `npm run openapi:current`: implemented-only Swagger generator (requires dependencies).
- `apps/api/test/unit/`, `integration/`: source tests including real PG tests, no mocks for concurrency.
- `reference/Phase_02/`: preserved Phase02 original and reference documents.
- `docs/verification/DEFERRED_TEST_REGISTER.md`: explicit unresolved release obligations.
- `evidence/phase04/`: actual local checks and blocked-runtime command output.

## Environment limitation at authoring time
PostgreSQL/Docker executable unavailable, npm Registry not accessible; genuine lockfile, NestJS runtime/typecheck, CI and DB migration tests remain unverified. This is a deliverable for further execution, **not a verified runnable release**. See `docs/engineering/PHASE_04_FINAL_REPORT_FA.md`.
