import {Pool} from 'pg';
/** Operator-run maintenance command. Uses the migration credential only, never the API runtime role. */
export async function pruneAuthRateLimits():Promise<number>{
 const migrationUrl=process.env.MIGRATION_DATABASE_URL;
 if(!migrationUrl)throw new Error('MIGRATION_DATABASE_URL_REQUIRED');
 const db=new Pool({connectionString:migrationUrl,max:1,connectionTimeoutMillis:5000});
 try {const result=await db.query(`DELETE FROM auth_rate_limits
    WHERE bucket_start < clock_timestamp()-interval '2 days'`);return result.rowCount??0;}
 finally {await db.end();}
}
if(require.main===module)pruneAuthRateLimits().then(count=>{process.stdout.write(`pruned ${count} old auth rate buckets\n`);})
 .catch(()=>{process.stderr.write('rate-limit maintenance failed\n');process.exitCode=1;});
