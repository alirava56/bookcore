# BookCore — Phase 03 backend foundation

**Status: implementation candidate; NOT production-verified.** PostgreSQL gates from Phase 02 are still `NOT VERIFIED`. The owner has authorized *deferring* infrastructure-dependent verification to final integration, not waiving it. This repository intentionally exposes only two HTTP routes. No login, booking HTTP endpoints, worker or payment processor exists yet.

## What is included

- NestJS modular monolith foundation (`apps/api/src/`), JSON logging, request IDs, defensive HTTP error handling (RFC 9457), strict configuration, default-deny authz port.
- `GET /api/v1/health/live` (anonymous, process only); `GET /api/v1/health/ready` (exact source-IP allowlist AND `X-BookCore-Monitor-Key`, PostgreSQL/schema check).
- SQL-first PostgreSQL connection/transaction foundation with `READ COMMITTED`, bounded `40P01`/`40001` retry and `UnknownCommitOutcome` error to be recovered via the *original* idempotency key. No completed booking workflow is exposed through HTTP.
- Four byte-for-byte preserved Phase 02 migration candidates. **They are unverified SQL; do not apply to production**. A new checksum ledger is introduced under `bookcore_migrations`.
- Original Phase 01 design files in `docs/`; exact original Phase 02 ZIP in `reference/Phase_02/`; extracted original spike code and tests under `reference/Phase_02/runnable-spike/`.

## Required environment

Node.js **22.16.0**, npm 10+, PostgreSQL **17.6** (or a validated 17.x), Docker Compose, npm registry connectivity for first install. The package manifest selects NestJS 12.6.0 / Swagger 12.1.2 and TypeScript 5.8.3. These versions are declared, **not installed or compatibility-tested here**. `package-lock.json` is intentionally absent because a legitimate dependency resolution could not be performed in the authoring environment (`EAI_AGAIN`); never fabricate a lockfile. This is an outstanding reproducibility blocker.

### Generate real lockfile and install (online, once)

```bash
cd bookcore
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
npm ci --no-audit --no-fund
npm run verify:reference
npm run verify:static
npm run typecheck
npm run lint
npm run build
npm run test:unit
```

Commit the real lockfile before running CI or building Docker images. Do not use `npm install` in CI as a silent substitute for `npm ci`.

### Local PostgreSQL and migrations

Use independent random development-only passwords, not `.env.example` placeholders. Run from the repository root:

```bash
export PG_DEV_OWNER_PASSWORD="$(openssl rand -hex 24)"
export PG_DEV_APP_PASSWORD="$(openssl rand -hex 24)"
export MONITOR_API_KEY="$(openssl rand -hex 32)"
docker compose -f infra/docker/compose.yml up -d postgres
# Source local environment without committing secrets; database role created on first boot.
export MIGRATION_DATABASE_URL="postgres://bookcore_owner:${PG_DEV_OWNER_PASSWORD}@127.0.0.1:55432/bookcore"
export DATABASE_URL="postgres://bookcore_app:${PG_DEV_APP_PASSWORD}@127.0.0.1:55432/bookcore"
export NODE_ENV=development
export MONITOR_ALLOWED_IPS=127.0.0.1,::1
npm run migrate
npm run migrate  # verifies checksum ledger; must not reapply existing migration SQL
# Grant only the permissions appropriate to the eventual tested application paths.
# For present integration-only ledger query:
psql "$MIGRATION_DATABASE_URL" -c 'GRANT SELECT ON public.bookcore_migrations TO bookcore_app'
npm run test:integration
npm run openapi:current
npm run start
```

A full API container can be started with `docker compose -f infra/docker/compose.yml up --build -d` **after** a genuine lockfile exists and after migrations. Docker Compose is development infrastructure, not a production infrastructure approval. API readiness in Compose will remain unavailable until migrations are applied. `docker compose -f infra/docker/compose.yml down` stops it; `down -v` **deletes your development database**.

**Health requests:**

```bash
curl -i http://127.0.0.1:3000/api/v1/health/live
curl -i -H "X-BookCore-Monitor-Key: $MONITOR_API_KEY" http://127.0.0.1:3000/api/v1/health/ready
```

Behind a reverse proxy, whitelist the **direct TCP peer IP** (or an explicitly secured private monitoring sidecar); an untrusted `X-Forwarded-For` is deliberately ignored. Running inside Docker has a different peer IP from direct host access; set `MONITOR_ALLOWED_IPS` to the *verified* private peer IP, not a broad subnet. Avoid exposing `/health/ready` through a public reverse proxy.

### Tests and contracts

```bash
npm run test:unit           # HTTP bootstrap tests use controlled DB test doubles (NOT PG evidence)
npm run test:integration    # requires actual PostgreSQL 17 with four migrations
npm run openapi:current     # generates only the two implemented health routes
```

`docs/api/openapi.yaml` is the **full Phase 01 future design contract**, not an implementation claim. `/docs` Swagger UI is disabled by default and prohibited in production. Neither CI nor Phase 02 concurrency experiments were executed in this authoring environment. The original Phase 02 spike is separately reproducible under `reference/Phase_02/runnable-spike/BookCore_Phase_02/` with its original README; it has no valid lockfile and requires independent execution before any Phase 02 Gate can PASS.

## Known boundaries and security

- No JWT verification, active session store, role membership authorization, object-level access checks or booking controllers yet. All future protected routes **must remain inaccessible** until real auth exists. No client-provided tenant ID constitutes authorization.
- The runtime PostgreSQL role `bookcore_app` must not be schema owner. Its DML grants remain deliberately unconfigured pending validated least-privilege SQL migrations/permissions.
- Phase 02 integrity triggers have not been tested on PostgreSQL 17; unknown COMMIT, deadlocks, idempotency and resource exclusion remain release blockers.
- `MIGRATION_DATABASE_URL` required only by migration script; do not expose it to API container. No passwords, tokens, DB dumps or `node_modules` are included.

See `docs/engineering/PHASE_03_FINAL_REPORT_FA.md` for statuses, `docs/verification/DEFERRED_TEST_REGISTER.md` for all deferred gates, and `MANIFEST.md` for SHA-256 inventory.
