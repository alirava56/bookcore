import { Module,Global } from '@nestjs/common';
import { AppConfigModule } from './config/app-config';
import { DatabaseModule } from './infrastructure/database/database.module';
import { HealthModule } from './modules/health/health.module';
import { JsonLogger } from './common/logging/json-logger';
import { ProblemFilter } from './common/errors/problem.filter';
import { DefaultDenyGuard } from './common/security/authorization';
@Global()
@Module({providers:[JsonLogger,ProblemFilter,DefaultDenyGuard],
 exports:[JsonLogger,ProblemFilter,DefaultDenyGuard]})
export class CommonModule {}
@Module({imports:[AppConfigModule,CommonModule,DatabaseModule,HealthModule]})
export class AppModule {}
