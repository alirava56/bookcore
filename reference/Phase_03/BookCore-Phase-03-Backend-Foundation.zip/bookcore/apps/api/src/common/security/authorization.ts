import { CanActivate,ExecutionContext,Injectable } from '@nestjs/common';
import { ProblemException } from '../errors/problem';

export type MembershipRole = 'OWNER'|'MANAGER'|'RECEPTIONIST'|'TRAINER';
export interface AuthenticatedPrincipal { userId:string; sessionId:string; active:boolean; }
export interface AuthorizedTenantContext {
  principal:AuthenticatedPrincipal;
  organizationId:string;
  membershipId:string;
  membershipRole:MembershipRole;
}
export type Decision = {allow:true;scope:AuthorizedTenantContext}|{allow:false;reason:string};
export interface AuthorizationPort {
  authorize(principal:AuthenticatedPrincipal,tenantId:string,operation:string,resourceId?:string):Promise<Decision>;
}
// No credential verifier/ACL store yet. All future protected routes must use a real provider;
// until that exists, this guard must always deny. It is never silently bypassed.
@Injectable()
export class DefaultDenyGuard implements CanActivate {
  canActivate(_ctx:ExecutionContext):boolean {
    throw new ProblemException(401,'AUTHENTICATION_NOT_IMPLEMENTED');
  }
}
