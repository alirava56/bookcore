import { Inject, Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool, type PoolClient } from 'pg';
import { APP_CONFIG, type AppConfig } from '../../config/app-config';

@Injectable()
export class DatabaseService implements OnModuleDestroy {
  private readonly pool:Pool;
  constructor(@Inject(APP_CONFIG) private readonly config:AppConfig) {
    this.pool=new Pool({
      connectionString:config.databaseUrl,
      max:config.dbPoolMax,
      connectionTimeoutMillis:config.connectionTimeoutMs,
      idleTimeoutMillis:30000,
      application_name:'bookcore-api',
    });
    // A network error on an idle client otherwise becomes an unhandled EventEmitter error.
    this.pool.on('error',()=>{ /* no credentials or raw SQL in logs; readiness will fail */ });
  }
  async connect():Promise<PoolClient> { return this.pool.connect(); }
  async ready():Promise<boolean> {
    try {
      const result=await this.pool.query({
        text:"SELECT to_regclass('public.bookcore_migrations') IS NOT NULL AS migrated, to_regclass('public.sessions') IS NOT NULL AS sessions_exists",
        query_timeout:this.config.healthQueryTimeoutMs,
      });
      return result.rows[0]?.migrated===true && result.rows[0]?.sessions_exists===true;
    } catch { return false; }
  }
  async onModuleDestroy():Promise<void> { await this.pool.end(); }
}
