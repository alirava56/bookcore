import { writeFileSync } from 'node:fs';
import { DocumentBuilder,SwaggerModule } from '@nestjs/swagger';
import { buildApplication } from '../apps/api/src/bootstrap';

async function generate():Promise<void> {
  const app=await buildApplication();
  try {
    await app.init();
    const config=new DocumentBuilder().setTitle('BookCore Phase 03 implemented routes only')
      .setVersion('0.3.0').addApiKey({type:'apiKey',in:'header',name:'X-BookCore-Monitor-Key'},'monitorAuth').build();
    const document=SwaggerModule.createDocument(app,config);
    const output=process.env.OPENAPI_CURRENT_OUTPUT || 'docs/api/implemented.openapi.json';
    writeFileSync(output,JSON.stringify(document,null,2)+'\n');
    const paths=Object.keys(document.paths ?? {});
    if(paths.length!==2 || !paths.includes('/api/v1/health/live') || !paths.includes('/api/v1/health/ready'))
      throw new Error('IMPLEMENTED_OPENAPI_ROUTE_MISMATCH');
  } finally { await app.close(); }
}
generate().catch(()=>{process.stderr.write('Implemented OpenAPI generation failed.\n');process.exitCode=1;});
