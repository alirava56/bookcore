# BookCore Phase 03 — SHA-256 file inventory

**Date:** 2026-11-22. **Scope:** all packaged project files except this MANIFEST.md (self-hash would be recursive).
**Verification:** static integrity checked; NestJS/PG runtime tests not executed; no authentic npm lockfile available.

| Relative path | SHA-256 | Bytes | Role |
|---|---|---:|---|
| `.dockerignore` | `53a07051b93a242500d993a259d3fec8f858664a1835758f5284dfaf8b211825` | 78 | configuration / execution script |
| `.env.example` | `f224087eeb3a8bf70c9534464d47b132ec192b19cd2498f3c27466f35a299cf0` | 893 | configuration / execution script |
| `.github/workflows/backend-phase03.yml` | `19c6c624cbab176ead4d88654746d90c6334741c6a811faaccd3a95afb1f1de5` | 2454 | container / CI configuration |
| `.gitignore` | `591ba6a7b0e292716174bc1e4b5b98eab7cebfe4bcfd576e75fb2fb823efd435` | 84 | configuration / execution script |
| `.prettierrc.json` | `673f7eb35df241be018376a802510f823debcb35aff3f8fbb3efcd892c228d95` | 60 | configuration / execution script |
| `README.md` | `cb5c9c1514e8fb4868b6b313cb0d776b7c121e55f15c7c62743b23f869d3f200` | 6276 | configuration / execution script |
| `apps/api/src/app.module.ts` | `1fe92c02ae1a8dd604116f9586f75389a831a43a63abf03f377809bab39b345b` | 695 | NestJS source and tests |
| `apps/api/src/bootstrap.ts` | `bf419e20fd0625be7c47272d329978335167d2ab898bf258738cb650763124b4` | 2835 | NestJS source and tests |
| `apps/api/src/common/errors/problem.filter.ts` | `b7d94f9e08646a90ff880748b36d75e23cfc72fc42a7c60e80dee541f82a4c7f` | 1292 | NestJS source and tests |
| `apps/api/src/common/errors/problem.ts` | `ee241f2d9863d2682186423e0ac0e3f76caf69ff6a72d0b2483db44ab11edfbc` | 1582 | NestJS source and tests |
| `apps/api/src/common/logging/json-logger.ts` | `711d842157ba4859815d066b249c79a8ae3e3528c258e6fb7e01e2566e415b78` | 1480 | NestJS source and tests |
| `apps/api/src/common/observability/request-context.ts` | `8483e1be67e6b111511e13dcfd3f028231f8ed031cfb31acca69a03361003a77` | 475 | NestJS source and tests |
| `apps/api/src/common/security/authorization.ts` | `2bf915978760a30b3e75392231b1f0203cabaac021ecb0bb9c5dcbec39a83347` | 1077 | NestJS source and tests |
| `apps/api/src/common/security/monitor.guard.ts` | `6f94e40d00ad77e973b2ba72d44b84e73b0f4f9e0cceb8fdd26c70f2d263fc49` | 1561 | NestJS source and tests |
| `apps/api/src/config/app-config.ts` | `851fb51e1924fd6a251c6d57aeb32bb4f436b289af472fb17703314effc190af` | 4302 | NestJS source and tests |
| `apps/api/src/infrastructure/database/database.module.ts` | `d887e7693f1af1e5ccf8d0f2910ef09ae44bd855014fc8e21ed80cfcd8b1d89d` | 407 | NestJS source and tests |
| `apps/api/src/infrastructure/database/database.service.ts` | `c069e010e5de3118dbc716498fb72860f2921089ec150a22a8ae72b8fde93142` | 1349 | NestJS source and tests |
| `apps/api/src/infrastructure/transactions/sqlstate.ts` | `9e5511e032798e4e795a99e34e70c9756f311e544ac2cafb498abf0e939709c6` | 1041 | NestJS source and tests |
| `apps/api/src/infrastructure/transactions/unit-of-work.ts` | `be615a17c0d70c9f967dda646917510332c34bcbb31fff6b6a856eedb2101dcf` | 2337 | NestJS source and tests |
| `apps/api/src/main.ts` | `2935dfee8ae095be2cbe02332c402f9a81e07c7da0d1786e83417ad058790d59` | 556 | NestJS source and tests |
| `apps/api/src/modules/booking/booking-sql.adapter.ts` | `0112adc75e25eab49b8dbe76ef6161fc13de06045c58783ec27fbc503727c148` | 1247 | NestJS source and tests |
| `apps/api/src/modules/health/health.controller.ts` | `ae0357e66b88cdc4f30bde5c7e3cad6fa254bbcf71089e08f090d011522d77ef` | 1323 | NestJS source and tests |
| `apps/api/src/modules/health/health.module.ts` | `ab3a87d2f1d28197d942fc01eeed588e5793eda9fa2ea09b5096a4c8b23d8d57` | 261 | NestJS source and tests |
| `apps/api/test/integration/postgres.test.ts` | `77cb0cbcd0bba5ff4ca617a18b96d115909636ece13e7d69c8519762502d1aa2` | 1069 | NestJS source and tests |
| `apps/api/test/unit/config.test.ts` | `3e271750b2f7c3c769bbe220fa2dc8b651b391a6ef24d03664a1763acd3ce0ee` | 1738 | NestJS source and tests |
| `apps/api/test/unit/database-ready.test.ts` | `59e0be4b90c231cfab0ec324537cf8ab0a03d8d3d882cab4da2078b2e54ba6cd` | 1139 | NestJS source and tests |
| `apps/api/test/unit/errors.test.ts` | `3f2a38fab82e0675c757214a8e16b09ad8c7de4c009b120aee13bf40b2791264` | 1185 | NestJS source and tests |
| `apps/api/test/unit/http.test.ts` | `1d81bd4ef70803811a61a0ba980f21508e1cca9cf7a4a071462626d177671fa9` | 1904 | NestJS source and tests |
| `apps/api/test/unit/security.test.ts` | `d617fcff8f50d572c85001d4cdeaa2bcb59d62af65c9e8109bb30fb8480d43b7` | 1671 | NestJS source and tests |
| `apps/api/test/unit/transaction.test.ts` | `a409c7feaa6fbdefdb878e1a0b8c80e41250fef5222d4b397d8bc9e4b974a647` | 2814 | NestJS source and tests |
| `apps/api/test/unit/validation.test.ts` | `4154690200b669f428416988697ac3916c2f03534eb482705f749cc30869455c` | 816 | NestJS source and tests |
| `db/migrations/001_core.sql` | `d83fdc0165aca2ad451a8aeeabaa13b24419632b1bebd1e84ad8705552c17454` | 14611 | unchanged provisional Phase 02 migration |
| `db/migrations/002_resource_guard.sql` | `ca330e5e009baed904384724304658aeef578bd4d1a04c53067b0a8c7e0fc728` | 767 | unchanged provisional Phase 02 migration |
| `db/migrations/003_hardening.sql` | `ec225d749b25eb6372e0723318f2553a1774876f4138761353ffec7653835798` | 7979 | unchanged provisional Phase 02 migration |
| `db/migrations/004_history_consistency.sql` | `4a5bb3c92384d8aa9e71e2822ce74d4bc0c31e12be6fbf04ea4879ddb77b89dd` | 9026 | unchanged provisional Phase 02 migration |
| `docs/api/openapi.yaml` | `5f28b246a01ee6b733c53f70c32eef09383e8013f5f11b75b040288b170f5f6b` | 90120 | engineering document |
| `docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | 1290 | engineering document |
| `docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | 1557 | engineering document |
| `docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | 1378 | engineering document |
| `docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | 1408 | engineering document |
| `docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | 2256 | engineering document |
| `docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | 997 | engineering document |
| `docs/architecture/ADR/ADR-020-PHASE03-FOUNDATION-AND-DEFERRED-RUNTIME.md` | `18bdec44006c71f901533b038baf23812a8983772626470ea27d5641297721fc` | 1932 | engineering document |
| `docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | 908 | engineering document |
| `docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | 16417 | engineering document |
| `docs/architecture/BACKEND_STRUCTURE_FA.md` | `b11e5b4a75beabb7141d7176785784a31ce78240d7ac365ed6b7d36b048c207a` | 3393 | engineering document |
| `docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | 19033 | engineering document |
| `docs/database/DATABASE_INTEGRATION_FA.md` | `44777741f162c35ff8dd50e2b0c2c727adc103e4b80bc7fca376e4df38757fea` | 3852 | engineering document |
| `docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | 11946 | engineering document |
| `docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | 7400 | engineering document |
| `docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | 9126 | engineering document |
| `docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | 6247 | engineering document |
| `docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | 18928 | engineering document |
| `docs/engineering/PHASE_03_FINAL_REPORT_FA.md` | `0f730045a9b2233d01c65d1f25caa11e03dcca0d0ebeb46114f8427b939f6f37` | 8741 | engineering document |
| `docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | 10032 | engineering document |
| `docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | 10271 | engineering document |
| `docs/security/SECURITY_FOUNDATION_FA.md` | `7ddf83b9fabcbbf4d319a974a23ea10aca09b8802d322357ef0d12f12226ac63` | 2683 | engineering document |
| `docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | 8109 | engineering document |
| `docs/verification/DEFERRED_TEST_REGISTER.md` | `bb83a9e4df2b1b8c6d63ce7bd56ea6bbc85a31eb1e6da1f0e07c6ed77ee82f78` | 6360 | engineering document |
| `docs/verification/PHASE_03_CHECKLIST.md` | `b9fe5e7667b10f66f31e4a171f0719299f6f4a17631ff69d02b665e85f30ff79` | 1812 | engineering document |
| `docs/verification/PHASE_03_TEST_EVIDENCE.md` | `8f00353a13a5a76b925093d6c78ac65034afb0b1ca0320b6bcbfecb7c265d322` | 2958 | engineering document |
| `docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | 14829 | engineering document |
| `docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | 4303 | engineering document |
| `eslint.config.mjs` | `d0b78e46807452fb689d313734f0ca018b81db979f012f9dd5bec7b6294a5103` | 383 | configuration / execution script |
| `evidence/build_attempt.log` | `704aa72a16456b6b3e2e343daeabb5677bf081909a2a4d70f5a6dd33b718e1f2` | 11795 | observed static or blocked-run evidence |
| `evidence/build_attempt_final.log` | `f4204bd57e3e7d9242672db482bfd91e4fb0e6c4cfe20335caa2857b38561b95` | 11795 | observed static or blocked-run evidence |
| `evidence/ci_yaml_parse.log` | `df5980d827fef941242b47d3f7812ae0633bb8b9a7319d331a7db65fbf85f47a` | 184 | observed static or blocked-run evidence |
| `evidence/lint_attempt.log` | `6c053306829fe7ce88401dc7f9c5b89167a2eb741607dd4362a9acfe6948760c` | 140 | observed static or blocked-run evidence |
| `evidence/node_npm_environment.log` | `4b3712a53279f7056a98c312e264214c9fe6e0300330015001494de79c4e19af` | 76 | observed static or blocked-run evidence |
| `evidence/noemit_check.log` | `2a72072f07b92705bb156968105797774041f46e57d00b37c1b87133d111e277` | 70 | observed static or blocked-run evidence |
| `evidence/npm_ci_attempt.log` | `2e62d799b46f4f569d88dd4dcd049f6d2110d1257ee0cef8448170957df679b4` | 1192 | observed static or blocked-run evidence |
| `evidence/npm_lockfile_attempt.log` | `edf1f733d89d0573aa2d64869ec1e52323765b876f67c1c4a3c992422bfa013a` | 53 | observed static or blocked-run evidence |
| `evidence/phase01_yaml_parse.log` | `e5fe9057a12c7ce98870bb759c3194ee3878af38882ed7ba985c4122106ddc49` | 53 | observed static or blocked-run evidence |
| `evidence/phase02_migration_provenance.log` | `cd9964887f9a0456ef0e22637e989cb06326130a0d12b7dc1c5cd752ccdfc34e` | 462 | observed static or blocked-run evidence |
| `evidence/phase03_test_summary.json` | `d142c8018fb44a9eb4dbb02cc4599c82e22f0d1ff7b9eecf2fb16df52373dc6f` | 1890 | observed static or blocked-run evidence |
| `evidence/reference_check.log` | `1c91bf987cb0aaa9f126afe707c93022a8932a2f426aa5715f6899e2b9656324` | 103 | observed static or blocked-run evidence |
| `evidence/static_check.log` | `689fedf22e6d06316d6cc580ecb108c5a0a3138e427f06844e9c94a9e8a9d4d7` | 76 | observed static or blocked-run evidence |
| `evidence/typecheck_attempt.log` | `1459dfbccaecd001fd258a7e97d0af463ee6155709303fabe21c59ee9f1d577d` | 11808 | observed static or blocked-run evidence |
| `evidence/typescript_syntax.log` | `e88e5925c3e5ac1bf1d7d78fbee1bac0b2373bc9eadbbe51a102a631d1ea3d47` | 62 | observed static or blocked-run evidence |
| `evidence/unit_test_attempt.log` | `56fa08260d618b9c8a0c70ae14cbfe634b4755b519bc513d1f1730fc68939bf6` | 119 | observed static or blocked-run evidence |
| `evidence/zero_test_runner_selftest.log` | `afa24c8233b713441b8b1f10e65604082e0ebedb3ec0196ffc6d6b8b806389f4` | 73 | observed static or blocked-run evidence |
| `evidence/zero_tests_guard.log` | `311ed8b9006fe9e9c4aaa67b8495fcb34d47839b509a85c0415d2bc2abd7a29e` | 130 | observed static or blocked-run evidence |
| `infra/docker/Dockerfile` | `0b4c453b4a9a38230463330f515e76efb34330d6522e0cb28804b46f1485e3a2` | 552 | container / CI configuration |
| `infra/docker/compose.yml` | `7bdc93c548a914c3baab83153fbe69cbc340f01d84b2e7fa800f6cb064ebf7a5` | 1642 | container / CI configuration |
| `infra/docker/init-db.sh` | `d87a4a4591b250252b7826d7ba6a3b36cc279a1f8e79a974d1eca0a22c6986df` | 343 | container / CI configuration |
| `package.json` | `91e54fdeb2bda645dca95831d7900ec55077cdef95136f615cc1e6f7063444fe` | 1608 | configuration / execution script |
| `reference/Phase_02/BookCore-Phase-02-Technical-Spike-Final-Verified.zip` | `3da3f894ff4a55c20ef3ff1ae666169c1461f6fb7f0230dee55be8a22e8efcab` | 696320 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/.github/workflows/postgres-spike.yml` | `5a3c8e5cc9f2d0f3b7229a66efb57e7782db47f7c94284d76d2460eb4ba010e3` | 2374 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/infra/docker-compose.yml` | `bb9f4f343b3da743e97bb447b057cba14d75684c001e9193ed1542bd08a2e706` | 520 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/BOOKCORE_SOFTWARE_ENGINEERING_BLUEPRINT_FA.md` | `3eb10bbc6a2679db4f70b7ef574369a2bf8b315b9585cb3b504ed4cf46609da5` | 61655 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/MANIFEST.md` | `e2b3da9791463bff793c58d3bc981f3d99ea2d317afba4f2388c8b5f3e6a9b2e` | 5572 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/README.md` | `091f74f733f66949f74bfae1fb2c71f511870f8859503286b87d790ac8ab896d` | 2017 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/api/openapi.yaml` | `5f28b246a01ee6b733c53f70c32eef09383e8013f5f11b75b040288b170f5f6b` | 90120 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | 1290 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | 1557 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | 1378 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | 1408 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | 2256 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | 997 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | 908 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | 16417 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | 19033 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | 11946 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | 7400 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | 9126 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | 6247 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | 18928 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | 10032 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | 10271 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | 8109 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | 14829 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | 4303 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/reference/Phase_01/BookCore_Phase_01/tools/validate_phase01.py` | `4baaf52f3bccd006c6623322695252b850bdc205f3d51c62b0b1425a46e9af2b` | 19841 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/.env.example` | `85f7ba4de1c53d4607f30e801898679aab818cdcfc7776c2cde9b8d139dd2b61` | 226 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/001_core.sql` | `d83fdc0165aca2ad451a8aeeabaa13b24419632b1bebd1e84ad8705552c17454` | 14611 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/002_resource_guard.sql` | `ca330e5e009baed904384724304658aeef578bd4d1a04c53067b0a8c7e0fc728` | 767 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/003_hardening.sql` | `ec225d749b25eb6372e0723318f2553a1774876f4138761353ffec7653835798` | 7979 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/migrations/004_history_consistency.sql` | `4a5bb3c92384d8aa9e71e2822ce74d4bc0c31e12be6fbf04ea4879ddb77b89dd` | 9026 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/package.json` | `a6dd8f6577b5584e21f346fbf61292b91e3f69ec11193dde1b897b2a09b8ac6d` | 839 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/db.ts` | `6b05b15d831e56693864a62a68d47c8ec3c37553e46c9dd7c5a94ccf35146fe0` | 3697 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/fixtures.ts` | `11e60843f7e7a319fc1025fbdac7a91cb25bc75c6595a093009d90c1ee288e9a` | 5715 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/migrate.ts` | `a0fd5aa1bfcf44b9d2d2870df2593a06c780598f0f1f302b38e75336efa27976` | 1698 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/operations.ts` | `c4e1f0b2a5e5270be7b3c7729b7a205785f94d8dc29383658bf3625606b96824` | 13456 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/reconcile.ts` | `427e906498bff25b055868a9ad2700703be47283d2fdcc06d5bc746005007780` | 3794 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/src/worker.ts` | `f9cf9e44aaa9954041e36ec1b9d7826e61b9a0769f207ef401a12a8dfe6d0e8b` | 1824 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/tests/spike.test.ts` | `6a37c0705b8db8f220911401855ab7a334446b5b3f06a51d9f3511a6e547f793` | 37322 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/spike/tsconfig.json` | `19d6366451313279b4509584c3f599e11f7474533872a99c6d9c0f34ebd14f0d` | 407 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/package_phase02.py` | `a5b1b4b5772dc59f143e5438aa7539d5268af7b197807d0965c4d442b1f4d83d` | 3503 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/package_verified.py` | `77803f867dfe99c1dcb5853981ad0e48833d4f58907f40ab142686af7e8a7f79` | 3492 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/run-local.sh` | `75b0802ea2681d9ddb4403433ad72dd7bc94db3d03e65df23929aad50c302d45` | 698 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/run_tests.mjs` | `6ca275b50d0d4e8b767a5df39c06c808def073688509750a7fb45c81ab9471fa` | 4225 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/static_checks.mjs` | `6add3a94a741968165bc698774ac05856b17ffaed4d0a7cc0a07f2dc37af503b` | 4264 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/verify_package.py` | `0e34f3b614082348ed27995731c3b39d7f98012f542c96da9b469b3828b2064e` | 1273 | verified baseline / original spike |
| `reference/Phase_02/runnable-spike/BookCore_Phase_02/tools/verify_reference.py` | `81d1c927b796f9c5e0c1b370884e0e0f6ba1af6aa810e7da5b92d16b1f8d8d29` | 739 | verified baseline / original spike |
| `scripts/check-clean-archive.cjs` | `dee3aa09ed1529db1271f737d98b0dcb8680dcb08a4a6ea35e0d81c913fa3582` | 478 | configuration / execution script |
| `scripts/generate-openapi.ts` | `8f287c5703014f1a2cbeaeba18ed6763738b9c68e1da0c7030984de441b0e25b` | 1077 | configuration / execution script |
| `scripts/migrate.ts` | `5cef95564e6e27ac305950aa28145272c0a6b066921e61bc57f1c7d2b092aa0e` | 2486 | configuration / execution script |
| `scripts/run-tests.cjs` | `0849b5c586b8863501622a04fce5224412b9dd769ebc5cb1a5926ebe2c81d526` | 2043 | configuration / execution script |
| `scripts/selftest-zero-runner.cjs` | `4d941dcb24a6cc4f8df4ebca0c0d2923ef9e5de4daba7fb6a9d12c0444a7a0dd` | 1801 | configuration / execution script |
| `scripts/static-verify.cjs` | `099d6fe9a7469735686b5a19cae52a2255a5943ec49b01b6d473984e03e31e5a` | 1665 | configuration / execution script |
| `scripts/verify-manifest.cjs` | `d3f8b06abc0b1dda14188197955f115358e1c26b7fb41bb2ee623fcebcc87730` | 1279 | configuration / execution script |
| `scripts/verify-reference.cjs` | `7d954a55b2bc0268bc3c28a79961c797da873d9ca784ef59b3327beb87bd9c16` | 506 | configuration / execution script |
| `tsconfig.json` | `76eec1035bbbc7ca879b345f80f2ffc6126615db77a9f5bfabcb1bb4f397a6fb` | 684 | configuration / execution script |

## Baseline

Original Phase 02 ZIP SHA-256: `3da3f894ff4a55c20ef3ff1ae666169c1461f6fb7f0230dee55be8a22e8efcab`.
Four Phase 02 SQL migrations are byte-identical to the reference; see `evidence/phase02_migration_provenance.log`.
No production certification or successful database experiment is asserted.
