# BookCore — Final Phase 01 Engineering Package Manifest

**Package:** `BookCore-Phase-01-Engineering-Final.zip`  
**Compiled:** 2026-11-22  
**Design:** 1.1.1-design; original BC-SENG-001 v1.0 unchanged.  
**Scope:** Engineering design + static design verification only. No backend, deployment, migrations, credentials, secret keys, operational validation or stakeholder approvals.  
**File integrity:** SHA-256 for every archive file except this self-referential `MANIFEST.md`; ZIP CRC32 additionally verified at assembly.

| Relative path (inside `BookCore_Phase_01/`) | SHA-256 | Role |
|---|---|---|
| `BOOKCORE_SOFTWARE_ENGINEERING_BLUEPRINT_FA.md` | `3eb10bbc6a2679db4f70b7ef574369a2bf8b315b9585cb3b504ed4cf46609da5` | Original BC-SENG-001 v1.0 design baseline — byte-for-byte retained. |
| `README.md` | `091f74f733f66949f74bfae1fb2c71f511870f8859503286b87d790ac8ab896d` | Workspace orientation, scope and design-only status. |
| `docs/api/openapi.yaml` | `5f28b246a01ee6b733c53f70c32eef09383e8013f5f11b75b040288b170f5f6b` | Corrected OpenAPI 3.1 design-only contract: 38 operations, 31 paths, public/staff schemas. |
| `docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | Atomic capacity and cancellation policy. |
| `docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | Single-TX terminal idempotency protocol. |
| `docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | Trainer/room identity and resource allocation constraints. |
| `docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | Global customer identity, staff membership and race-safe revocation. |
| `docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | Scheduling input timezone vs UTC outputs, `/me` and public/staff API separation. |
| `docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | PostgreSQL-native features and ORM verification decision. |
| `docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | ADR index and interpretation guide. |
| `docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | Modular-monolith layout, locking, idempotency, outbox and API boundary. |
| `docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | PostgreSQL physical schema, constraints, GiST and UTC-instant semantics. |
| `docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | Domain entities, invariants, boundaries, ownership and read projections. |
| `docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | Booking/Session transitions and customer/staff cancellation visibility. |
| `docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | Baseline gaps, discrepancies and correction decisions. |
| `docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | Open product assumptions, technical spikes and risks. |
| `docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | Gate 1–8 evaluation and bounded final design verdict. |
| `docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | MVP scope, journeys, provisional product rules and corrected route contracts. |
| `docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | Authoritative exact 38-operation access and field-level authorization policy. |
| `docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | Threat categories, mitigations and links to canonical authorization. |
| `docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | FR-01..16, INV-01..14, NFR-01..10 and T-01..47 designs. |
| `docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | Actual strict YAML/OpenAPI/schema/ref/auth/cross-document checks and limitations. |
| `tools/validate_phase01.py` | `4baaf52f3bccd006c6623322695252b850bdc205f3d51c62b0b1425a46e9af2b` | Reproducible local static design validator (not a backend). |

## Verification scope
- `docs/verification/STATIC_DESIGN_VALIDATION.md` shows **19 PASS**, **0 FAIL**, **2 NOT VERIFIED** (external independent OpenAPI validator and runtime tests).
- These PASS values are **static design checks**, not successful integration/security/DB acceptance tests.
- Future TS-01..TS-07 and all T-01..T-47 are unexecuted against a real backend.
- Design gate statuses 1–8 and the final verdict appear exclusively in `docs/engineering/PHASE_01_FINAL_REPORT_FA.md`.
- Re-run local static checks with `python tools/validate_phase01.py` from inside the archive folder after installing the reported Python validation libraries.
- Do not run the obsolete Phase-01 OpenAPI generator: the package includes the corrected authoritative `docs/api/openapi.yaml` and the validation script only.
