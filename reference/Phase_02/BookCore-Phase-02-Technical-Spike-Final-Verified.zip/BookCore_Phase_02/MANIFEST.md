# BookCore Phase 02 FINAL execution candidate — SHA-256 MANIFEST

**Generated:** 2026-11-22. **Provenance:** authoritative Verified Phase 02 ZIP preserved under `reference/original_phase02_verified/`; Phase 01 baseline unchanged.
**Status:** No PostgreSQL runtime experiment executed; NOT validated. Authentic npm lockfile missing due to EAI_AGAIN DNS failure. See PHASE_02_FINAL_REPORT_FA.md.
**Hashing rule:** Every packaged project file except this `MANIFEST.md` is listed below. Self-hashing the manifest would be recursive.

| Relative path | SHA-256 | Bytes | Role |
|---|---|---:|---|
| `.github/workflows/postgres-spike.yml` | `5a3c8e5cc9f2d0f3b7229a66efb57e7782db47f7c94284d76d2460eb4ba010e3` | 2374 | CI workflow |
| `README.md` | `967567806f50e0a1fe17494240fbf3038cb92c85a8e0f6ae43e1ac55012abff5` | 6061 | configuration/runbook/verification |
| `docs/phase-02/ADR/ADR-017-DEFERRED-INTEGRITY-SPIKE.md` | `74b2dc51aa0810ee5cba32df017d10e913b396534c9228c828e7c618e4b21835` | 1935 | engineering report or ADR |
| `docs/phase-02/ADR/ADR-018-DATABASE-MUTATION-GUARDS.md` | `63ac78ff78f959d5e833c7c6860c6a9f78fbcf432f05b633f13c76b385b24948` | 2290 | engineering report or ADR |
| `docs/phase-02/ADR/ADR-019-BOOKING-EVENT-CHAIN-AND-TERMINAL-METADATA.md` | `5ac35799ca03228943b125898aa66f5678fcb7edcc4b47197d57a3b53f1dfc01` | 3723 | engineering report or ADR |
| `docs/phase-02/CONCURRENCY_TEST_REPORT_FA.md` | `3dfaececf0f97775126c24a8e3a940bcf122f01fb526bdf4b0a3891b239bc954` | 2673 | engineering report or ADR |
| `docs/phase-02/DATABASE_INTEGRITY_REPORT_FA.md` | `e3db086eeb2fad00a79b8a980d7a95990ca7355d097ef39d4c30de997db6ad7d` | 3701 | engineering report or ADR |
| `docs/phase-02/FINAL_EXECUTION_AUDIT_FA.md` | `42b570bb5c216f7738479251cd0f46480cd8696885f4264fa43be83a039fd6e5` | 2845 | engineering report or ADR |
| `docs/phase-02/IDEMPOTENCY_VERIFICATION_FA.md` | `9138f1b0cc64a0489336fc4338b1c5523f454e43bf426ebf307b18e1356d321c` | 2506 | engineering report or ADR |
| `docs/phase-02/INDEPENDENT_AUDIT_FA.md` | `968af4a6e3cd9e62eaf26a0a913e0dc0e604157eceb71e30f89e5ac6fdca3a57` | 6885 | engineering report or ADR |
| `docs/phase-02/ORM_EVALUATION_FA.md` | `16fd279a92df97699ab2d3c90f400d3bb8ad949ad94ebe6845d5cd29594f3e12` | 2152 | engineering report or ADR |
| `docs/phase-02/PHASE_02_FINAL_REPORT_FA.md` | `05029b136bed6764df566fc3c3d18ac3721f6850a09cf7e0a805b568699e8854` | 10864 | engineering report or ADR |
| `docs/phase-02/REPRODUCIBILITY_REPORT_FA.md` | `584e0c9399791b8f27ff1c577fec342829022be51e46b586ffff306a30c393f4` | 2802 | engineering report or ADR |
| `docs/phase-02/RESOURCE_CONFLICT_TESTS_FA.md` | `12d2473dd765325efa2a5480d44486a063b86689cd561f8486f130a6be2ad0bc` | 2162 | engineering report or ADR |
| `docs/phase-02/SECURITY_BOUNDARY_FINDINGS_FA.md` | `50ec3afcf0217a18a370ee50468a7dba6146d2581dc1a56fa1115c46654cff50` | 2561 | engineering report or ADR |
| `docs/phase-02/TECHNICAL_SPIKE_PLAN_FA.md` | `ea650756c138f2c95f0074ac243826fe006e38bdbb0aeeb25e7376e59ca6fa88` | 4356 | engineering report or ADR |
| `docs/phase-02/TEST_EVIDENCE.md` | `9ba046a15416380b2e545d83e7d37ef41c99596cdaa52e7f267cb61980df277b` | 2925 | engineering report or ADR |
| `docs/phase-02/TRANSACTION_FAILURE_ANALYSIS_FA.md` | `91bda7e4591346d90d84b9f9858728e9735a1177f6c870ffccad9252fe0150b3` | 2461 | engineering report or ADR |
| `evidence/DEPENDENCY_RESOLUTION_ATTEMPT.txt` | `e984550df0d4772d7f1f1ca2aa7e626b0ccfeedea0f9eff5af44b986948eb6a0` | 14 | test/verification evidence |
| `evidence/RUNTIME_TEST_ATTEMPT.txt` | `441df058bd3e841176ae1beddadef9e819964556d6be3fc533d274be794a8af9` | 1549 | test/verification evidence |
| `evidence/STATIC_EXECUTION_LOG.txt` | `148249a712c267dff80b583d7433bc8ce8dc8d326c5e8f80a1516ec52eb36ba2` | 986 | test/verification evidence |
| `evidence/ci_yaml_parse.log` | `c0847bc5650bec51a73c8a7237b5036bab3979796e91b15a13cbef9609d5b8c1` | 115 | test/verification evidence |
| `evidence/final/build.log` | `1c93155249a10b98dcaa175f9afbd6e5084e486f831a52fbc60db3ed1a1408cd` | 15081 | test/verification evidence |
| `evidence/final/ci_yaml_parse.log` | `c3c9366f871a2cbae6b568077246e8ee684c344d9e035ab127708b5649d58d17` | 197 | test/verification evidence |
| `evidence/final/cleanroom_verification_attempt.log` | `78057cbc8586ea3b45628f270d1708911e01aea92be460946a2b23b2727c75af` | 3042 | test/verification evidence |
| `evidence/final/lint_custom_static.log` | `e6a01798b2e7b9c5fd88611843709e41fdb8687fe3a47e45a50df0fb83e41983` | 511 | test/verification evidence |
| `evidence/final/migrations.log` | `d42d9d9a561e3e9162813d096a29800e1a04fe7a64b6525524c4309701db80c7` | 939 | test/verification evidence |
| `evidence/final/node_scripts_syntax.log` | `0b960946f8a41eec605875364cc66776636f665f3b3ed8ad3d93982dd41a6eed` | 112 | test/verification evidence |
| `evidence/final/npm_ci.log` | `7e535535eebe7088bf7c9794d60e77bada0705bf74af1aa2d2d6611f612abc78` | 1277 | test/verification evidence |
| `evidence/final/npm_lockfile_resolution.log` | `952ec0dfa0dc54a59c5e5a35283fd15677c110551f33eb00583b495e80576efb` | 479 | test/verification evidence |
| `evidence/final/npm_test.log` | `ec9dbfb218d3c976e8a10fdbba6a4f318cc20842212289286e799613774971f9` | 277 | test/verification evidence |
| `evidence/final/reconciliation.log` | `905c2e323c88008a7cb596e5e8647ffcb16102a010b58e057d7fce3e6fb92f7c` | 947 | test/verification evidence |
| `evidence/final/reference_verification.log` | `43847a30f23e53d17e58539295ebc813729f0ab81c31e21ab25bfff8a42178e9` | 143 | test/verification evidence |
| `evidence/final/source_provenance.log` | `5013e7da0ef4f51353f973405b48ad3046fbdcf6a43e8215aa6e8fc24298f9b8` | 163 | test/verification evidence |
| `evidence/final/static_checks.log` | `657f18e7a2ec9d12f27e5a02f0691741adb51c6accd87bcaddb0ab9e87b83192` | 345 | test/verification evidence |
| `evidence/final/system_tools.log` | `2103b54cfb1bf1977c1a84d8a0f55aa3b18c322ee4c9269812300b7ba758b251` | 358 | test/verification evidence |
| `evidence/final/test_summary.json` | `9cb3de6e6fc45614b9c3ba866f2e07eeade5cfe4e188246ab60a28ec6c63021b` | 3314 | test/verification evidence |
| `evidence/final/typecheck.log` | `8be1a9875a4ba30c9172237b4bf5121383780a676cf7af0ae8c85c3a07670392` | 326 | test/verification evidence |
| `evidence/final/typescript_ast_syntax.log` | `4079214a6d49eca0f43e2f7f06c560ce7ecbf6e3bb8eeec3cbe09d1b4c640056` | 125 | test/verification evidence |
| `evidence/final/zero_tests_regression.log` | `d2e540834e044bb5bd2e979d908fce87dc5c605cd8a6b3e7dca73d1acdce4644` | 167 | test/verification evidence |
| `evidence/remediation_command_results.log` | `9953a77fd56ea92e8d892b1bea375f5a991754de72f43205311678b851844c9f` | 15940 | test/verification evidence |
| `evidence/test_summary.json` | `53c91fd89cf59974db0c8770c17eb4c1c5306da3062672f730d08ec3dc2c3da7` | 2377 | test/verification evidence |
| `evidence/typescript_syntax_check.log` | `50e63555670ce80fb44a58b949aaacbf5a6824ae16b5644bb4a8e8fff0e28824` | 145 | test/verification evidence |
| `infra/docker-compose.yml` | `bb9f4f343b3da743e97bb447b057cba14d75684c001e9193ed1542bd08a2e706` | 520 | configuration/runbook/verification |
| `reference/Phase_01/BookCore_Phase_01/BOOKCORE_SOFTWARE_ENGINEERING_BLUEPRINT_FA.md` | `3eb10bbc6a2679db4f70b7ef574369a2bf8b315b9585cb3b504ed4cf46609da5` | 61655 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/MANIFEST.md` | `e2b3da9791463bff793c58d3bc981f3d99ea2d317afba4f2388c8b5f3e6a9b2e` | 5572 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/README.md` | `091f74f733f66949f74bfae1fb2c71f511870f8859503286b87d790ac8ab896d` | 2017 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/api/openapi.yaml` | `5f28b246a01ee6b733c53f70c32eef09383e8013f5f11b75b040288b170f5f6b` | 90120 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-011-CAPACITY_TRANSACTION.md` | `3a1656a9eb09f8bb8537ff2724f4e0ae37dc7ca1ca526d06c424447311eee677` | 1290 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-012-IDEMPOTENCY_PROTOCOL.md` | `f508ab2d9a78bed1d41dd7a2c84f65242177efd1641a96e9877520bf4bc3710f` | 1557 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-013-RESOURCE_OWNERSHIP.md` | `28d2cf71a1bef257f0d6556484b2942f8591cf01a86f844f687668aea0e75bfa` | 1378 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-014-TENANT_AUTH_AND_LIFECYCLE.md` | `d1dc8cbf65ce9f745c4fcbb21911411afe1b59861cb5be6c2325856fe5b4f409` | 1408 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-015-TIME_AND_API.md` | `dde83a35910674da3ef7f51e509f3579db3eb231ed9be1e752604d31df4536ae` | 2256 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/ADR-016-DATABASE_FIRST_MIGRATIONS.md` | `7bb4906364a230fa973db786db5260b9b64d6781078c82214b49b8d754ab8d9d` | 997 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ADR/README.md` | `2180227c3fa7a836ebd0aa3f19e44e816b0ff8d674e391e3c739d9ab48f9cf25` | 908 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/architecture/ARCHITECTURE_FA.md` | `48bb335a399860205cb94e2716f71d3b6eac36a595988a285d2ce1ca31589cba` | 16417 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/database/DATABASE_DESIGN_FA.md` | `1326f57debf66ccc26866227a913cdec8c152ac4cfdf1f7af029b330b5334e73` | 19033 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/domain/DOMAIN_MODEL_FA.md` | `d053bb92d2637505285eb478b7e9768da8714069ffb9353a0c4def15e88c3b90` | 11946 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/domain/STATE_MACHINES_FA.md` | `ac46ef42c98342169f707b74c0e48009350813faa8c9787587f60197c69da560` | 7400 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/engineering/01_BASELINE_AUDIT_FA.md` | `2f22cf6fd3270e268d984679cab75465865013b3031703cd629434e373f8f23d` | 9126 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/engineering/OPEN_DECISIONS_FA.md` | `475792fa0a084dc7c7ae96cb1b6b36fdd06de12e386f680a630af2071fccda39` | 6247 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/engineering/PHASE_01_FINAL_REPORT_FA.md` | `37fa9fc4cb6c2f35d5c258e2ef5761132f3f04de00421774d0be74cf3225ef15` | 18928 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/product/PRD_FA.md` | `0afebe6ed7d581753cfac7e6483bbd77ec3a4217615d6dcd4bc26a9f09f62b2a` | 10032 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/security/AUTHORIZATION_MATRIX.md` | `c539750b3fe057c68b445987ed6345c65b42ce000a9a8173f5903a81cec9cb40` | 10271 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/security/THREAT_MODEL_FA.md` | `bf554cfc56843d003807365f56ce0932c396dbf7da9591899d2cebd73cab0de1` | 8109 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/verification/REQUIREMENTS_TRACEABILITY.md` | `f8106f63958c68e7b3ff35da01c0fb3d9fa3f1f0e9c4da5b0c201213051b2f0c` | 14829 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/docs/verification/STATIC_DESIGN_VALIDATION.md` | `89027c5aaed1c9a1d31ee851c3a1d41887b4a46a2d6668bd1389a3b1c16221a9` | 4303 | original immutable engineering reference |
| `reference/Phase_01/BookCore_Phase_01/tools/validate_phase01.py` | `4baaf52f3bccd006c6623322695252b850bdc205f3d51c62b0b1425a46e9af2b` | 19841 | original immutable engineering reference |
| `reference/original_phase02/BookCore-Phase-02-Technical-Spike.zip` | `8f6cf770a05e6e95227e3eb5bb048f1fbf56dcbaeae1c71019d17239454ededa` | 159787 | original immutable engineering reference |
| `reference/original_phase02_verified/BookCore-Phase-02-Technical-Spike-Verified.zip` | `45baabb184e0dcb0bd87109c5edb2cd2bc8fcb3679739c9de7bf6205100ed89c` | 341234 | original immutable engineering reference |
| `spike/.env.example` | `85f7ba4de1c53d4607f30e801898679aab818cdcfc7776c2cde9b8d139dd2b61` | 226 | runtime spike or regression source |
| `spike/migrations/001_core.sql` | `d83fdc0165aca2ad451a8aeeabaa13b24419632b1bebd1e84ad8705552c17454` | 14611 | runtime spike or regression source |
| `spike/migrations/002_resource_guard.sql` | `ca330e5e009baed904384724304658aeef578bd4d1a04c53067b0a8c7e0fc728` | 767 | runtime spike or regression source |
| `spike/migrations/003_hardening.sql` | `ec225d749b25eb6372e0723318f2553a1774876f4138761353ffec7653835798` | 7979 | runtime spike or regression source |
| `spike/migrations/004_history_consistency.sql` | `4a5bb3c92384d8aa9e71e2822ce74d4bc0c31e12be6fbf04ea4879ddb77b89dd` | 9026 | runtime spike or regression source |
| `spike/package.json` | `a6dd8f6577b5584e21f346fbf61292b91e3f69ec11193dde1b897b2a09b8ac6d` | 839 | runtime spike or regression source |
| `spike/src/db.ts` | `6b05b15d831e56693864a62a68d47c8ec3c37553e46c9dd7c5a94ccf35146fe0` | 3697 | runtime spike or regression source |
| `spike/src/fixtures.ts` | `11e60843f7e7a319fc1025fbdac7a91cb25bc75c6595a093009d90c1ee288e9a` | 5715 | runtime spike or regression source |
| `spike/src/migrate.ts` | `a0fd5aa1bfcf44b9d2d2870df2593a06c780598f0f1f302b38e75336efa27976` | 1698 | runtime spike or regression source |
| `spike/src/operations.ts` | `c4e1f0b2a5e5270be7b3c7729b7a205785f94d8dc29383658bf3625606b96824` | 13456 | runtime spike or regression source |
| `spike/src/reconcile.ts` | `427e906498bff25b055868a9ad2700703be47283d2fdcc06d5bc746005007780` | 3794 | runtime spike or regression source |
| `spike/src/worker.ts` | `f9cf9e44aaa9954041e36ec1b9d7826e61b9a0769f207ef401a12a8dfe6d0e8b` | 1824 | runtime spike or regression source |
| `spike/tests/spike.test.ts` | `6a37c0705b8db8f220911401855ab7a334446b5b3f06a51d9f3511a6e547f793` | 37322 | runtime spike or regression source |
| `spike/tsconfig.json` | `19d6366451313279b4509584c3f599e11f7474533872a99c6d9c0f34ebd14f0d` | 407 | runtime spike or regression source |
| `tools/package_phase02.py` | `a5b1b4b5772dc59f143e5438aa7539d5268af7b197807d0965c4d442b1f4d83d` | 3503 | configuration/runbook/verification |
| `tools/package_verified.py` | `77803f867dfe99c1dcb5853981ad0e48833d4f58907f40ab142686af7e8a7f79` | 3492 | configuration/runbook/verification |
| `tools/run-local.sh` | `75b0802ea2681d9ddb4403433ad72dd7bc94db3d03e65df23929aad50c302d45` | 698 | configuration/runbook/verification |
| `tools/run_tests.mjs` | `6ca275b50d0d4e8b767a5df39c06c808def073688509750a7fb45c81ab9471fa` | 4225 | configuration/runbook/verification |
| `tools/static_checks.mjs` | `6add3a94a741968165bc698774ac05856b17ffaed4d0a7cc0a07f2dc37af503b` | 4264 | configuration/runbook/verification |
| `tools/verify_package.py` | `0e34f3b614082348ed27995731c3b39d7f98012f542c96da9b469b3828b2064e` | 1273 | configuration/runbook/verification |
| `tools/verify_reference.py` | `81d1c927b796f9c5e0c1b370884e0e0f6ba1af6aa810e7da5b92d16b1f8d8d29` | 739 | configuration/runbook/verification |
