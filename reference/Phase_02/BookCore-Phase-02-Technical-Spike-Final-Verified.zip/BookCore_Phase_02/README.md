# BookCore — Phase 02 critical remediation (execution candidate, **NOT PROVEN**)

This is a separate corrected workspace built from the authoritative, SHA-verified, unmodified `BookCore-Phase-02-Technical-Spike-Verified.zip` dated 2026-11-22. **The authoring environment has no real PostgreSQL server, Docker, usable npm registry, or authentic npm lockfile. Do not promote this as a validated database design.** This is an independently reviewed *candidate* containing the source fixes and adversarial test scenarios necessary to seek runtime proof. Nothing has been deployed or pushed to GitHub.

## Provenance

- Unmodified authoritative Phase 02 Verified ZIP: `reference/original_phase02_verified/BookCore-Phase-02-Technical-Spike-Verified.zip` (SHA-256 `45baabb184e0dcb0bd87109c5edb2cd2bc8fcb3679739c9de7bf6205100ed89c`). Earlier archived Phase 02 ZIP: `reference/original_phase02/BookCore-Phase-02-Technical-Spike.zip` (SHA-256 recorded in `docs/phase-02/INDEPENDENT_AUDIT_FA.md`).
- Immutable Phase 01 reference: `reference/Phase_01/BookCore_Phase_01/` with restored **authentic** `MANIFEST.md`; all 23 referenced file hashes verified from the Phase 01 final ZIP. Original v1.0 blueprint remains unchanged.
- All extra Phase 02 corrections are confined to this workspace. See `MANIFEST.md` for the sha256 inventory.

## Current final execution findings (2026-11-22)

The fourth additive migration, `004_history_consistency.sql`, strengthens the BookingEvent chain and terminal metadata. Twelve database regression definitions were added (H01–H12), and independent history reconciliation was added. **None of these PostgreSQL tests could run here**; DNS lookup of `registry.npmjs.org` returned `EAI_AGAIN`, and Docker/psql were unavailable. An authentic `package-lock.json` could not be generated. Do not treat the ZIP filename as a validation claim. See `docs/phase-02/PHASE_02_FINAL_REPORT_FA.md` and `evidence/final/`.

## Setup: disposable environment ONLY

Prerequisites: Node.js **22.16.0**, npm, Docker+Compose or real PostgreSQL **17.11**, working access to npm registry. Run on a fresh isolated database, never on production. CI assumes the unpacked `BookCore_Phase_02/` directory is a repository root.

```bash
cd BookCore_Phase_02/spike
# ONE-TIME prerequisite on a connected machine: authentic dependency resolution.
npm install --package-lock-only --ignore-scripts
# Check package-lock.json into your own working copy; never invent hashes.
cd ..
docker compose -f infra/docker-compose.yml up -d --wait
cd spike
npm ci --ignore-scripts
npm run typecheck
npm run lint
npm run build
npm run migrate
npm run migrate                 # second run validates SHA and no duplicate application
BOOKCORE_MIN_TESTS=56 npm test # fails for zero tests, subprocess errors, skipped or failed tests
npm run reconcile
cd ..
docker compose -f infra/docker-compose.yml down --volumes
```

Or execute `bash tools/run-local.sh` **after** generating the authentic `spike/package-lock.json`; it intentionally refuses an unpinned install. Do not use a privilege-bearing role in production; this spike uses local test credentials and fixture-only identity checks. `.env.example` is not a secret.

## Clean-package checks (no PostgreSQL required)

```bash
cd BookCore_Phase_02
python tools/verify_reference.py
node tools/static_checks.mjs
node tools/run_tests.mjs --self-test
cd spike
npm test          # must FAIL until compiled tests exist
npm ci --offline  # currently FAILS: genuine lockfile not yet available
```

The static check verifies source signatures and original reference hashes; **it is not SQL validation**. The runner self-test actually launches an empty compiled test file to prove the zero-test condition fails. Once TypeScript is built using authentic dependencies, the same runner executes the compiled database tests. `npm test` does not silently succeed if no tests are compiled.

## File map

- `spike/migrations/001_core.sql`, `002_resource_guard.sql`: unchanged Phase 02 schema base.
- `spike/migrations/003_hardening.sql`: NEW reparenting/immutable history guards, deferred cross-table verification, resource edit serialization and state checks.
- `spike/migrations/004_history_consistency.sql`: added event-insert deferred checks, logical event ordering, terminal metadata integrity; no PostgreSQL execution yet.
- `spike/src/db.ts`: explicit PostgreSQL SQLSTATE/server-error classification; never blindly retry ambiguous COMMIT, bounded retry after release.
- `spike/src/migrate.ts`: migration SHA-256 drift detection, transactional application and repeat-run verification.
- `spike/src/worker.ts`, `spike/tests/spike.test.ts`: true fork-based test harness *when executed*, child IPC/pool teardown requirements; 55 static test() declarations (one capacity loop gives 56 expected runtime cases; no runtime discovery confirmed).
- `tools/run_tests.mjs`: rejects missing compiled tests, empty files, failed/skipped tests, timeouts and unexpected exit codes; contains an executable zero-test regression.
- `.github/workflows/postgres-spike.yml`: proposed PostgreSQL 17.11 + Node 22.16 CI; **not executed**, and will intentionally fail until an authentic lockfile is available.
- `evidence/final/`: actual final execution-attempt logs; `evidence/`: other observed command logs; `docs/phase-02/INDEPENDENT_AUDIT_FA.md`, `TEST_EVIDENCE.md`, `REPRODUCIBILITY_REPORT_FA.md`, `PHASE_02_FINAL_REPORT_FA.md`: independent assessment and observed results.

## Limitations and safe conclusions

A TypeScript compiler syntax parse completed with zero syntax diagnostics, but strict typechecking with real Node and pg types did **not** pass (dependencies unavailable). No PostgreSQL migration, test, concurrency experiment, SQLSTATE reproduction, privileged-role proof, ORM benchmark or real lost-ack experiment completed. No performance measurements exist. Executable test definitions are **not** runtime evidence. All eight technical gate decisions and detailed exceptions are recorded in `PHASE_02_FINAL_REPORT_FA.md`. **Phase 03 is not authorized.**
