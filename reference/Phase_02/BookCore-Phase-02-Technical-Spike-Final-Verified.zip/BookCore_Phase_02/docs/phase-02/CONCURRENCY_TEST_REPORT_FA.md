> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# گزارش آزمون هم‌زمانی

## طرح کد موجود
تست parameterized برای ظرفیت ۱ و ۲۰، هرکدام سه تکرار مستقل و ۱۰۰ Customer/Idempotency Key متفاوت. Parent دو Child Process با `fork` می‌سازد؛ هر Child Pool واقعی PostgreSQL خودش را خواهد داشت و ۵۰ درخواست را پس از پیام `go` شروع می‌کند. زمان آغاز/پایان، p50/p95/p99, successful/rejections/timeouts در ساختار `BOOKCORE_SPIKE_METRICS` آمادهٔ چاپ است. `SELECT … FOR UPDATE` روی یک Session نقطه serialization است.

## وضعیت واقعی و معیار موفقیت
| معیار | انتظار آزمایش | مشاهده‌شده |
|---|---|---|
| ظرفیت ۱ | ۱ تایید / ۹۹ رد صحیح | NOT VERIFIED |
| ظرفیت ۲۰ | ۲۰ تایید / ۸۰ رد صحیح | NOT VERIFIED |
| Counter = effective bookings | همیشه | NOT VERIFIED |
| سه تکرار مستقل | بدون timeout غیرعادی | NOT VERIFIED |
| Deadlock طبیعی | صفر در مسیر قفل مرتب؛ آزمایش معکوس باید 40P01 بدهد | NOT VERIFIED |
| Lock wait / throughput / pool | باید اندازه‌گیری شود | NOT VERIFIED |

`npm test` واقعاً فراخوانی شد، اما هنگام load، ماژول `pg` موجود نبود و Node با `ERR_MODULE_NOT_FOUND` خارج شد. **هیچ تست داده‌ای اجرا نشد.** این Fail زیرساخت است، نه شاهد باخت الگوریتم. به `evidence/RUNTIME_TEST_ATTEMPT.txt` مراجعه شود. Benchmark تولیدی یا اثبات مطلق هم‌زمانی ارائه نشده است.
