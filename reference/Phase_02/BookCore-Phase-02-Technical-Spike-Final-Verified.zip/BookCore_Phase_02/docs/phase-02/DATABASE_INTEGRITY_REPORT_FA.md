> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# بررسی سلامت دیتابیس — طراحی اجرایی، بدون اثبات Runtime

## پیاده‌سازی موجود
- Migration `001_core.sql`: ۱۳ جدول حداقلی `organizations`, `users`, `memberships`, `branches`, `resources`, `services`, `sessions`, `resource_allocations`, `bookings`, `booking_events`, `audit_events`, `idempotency_records`, `outbox_events`.
- FKهای composite `(tenant_id,id)`، `CHECK` ظرفیت، یکتایی جزئی رزرو مؤثر و GiST `EXCLUDE` منابع فعال با بازهٔ `[start,end)`.
- چهار `CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED`: ممنوعیت COMMIT رکورد `PROCESSING`، تطابق Counter، تعداد/هویت Allocation و زمان Buffer. `resource_allocations` فقط پس از غیرفعال‌سازی با تاریخچه باقی می‌مانند.
- Audit و BookingEvent غیرقابل ویرایش/حذف با trigger؛ Migration دوم تغییر Resource Buffer و مالکیت در حال Allocation فعال را می‌بندد. Query مستقل `reconcile.ts` Drift را بدون تغییر داده گزارش می‌کند.

## شواهدی که موجود نیست
SQLها فقط به‌صورت متن بررسی شده‌اند؛ PostgreSQL parser، Extension install، اجرای Migration، اجرای Trigger، بررسی Catlog/EXPLAIN و SQLSTATEهای واقعی در دسترس نبودند. کد تست‌های منفی برای `23503`, `23505`, `23P01`, `23514` نوشته شده ولی هیچ نتیجهٔ Runtime به دست نیامده است.

## ریسک‌های بازِ مشخص
- Trigger تعویقی با `FOR UPDATE` روی Session در مسیر noncooperative SQL می‌تواند Deadlock/قفل اضافی ایجاد کند؛ رفتار رقابتی بدون اجرای PG اثبات نشده است.
- Trigger بر `sessions/bookings/allocations` همهٔ سیاست‌های state machine را **به‌تنهایی** enforce نمی‌کند (مثلاً attendance فقط پس از Finish، و اعمال ساعت کاری). لایهٔ Business Service/Privileges همچنان الزام است.
- تغییرات Membership و organization status در ردیف‌های مستقل نیازمند الگوریتم مجوز رسمی خارج از Fixture هستند. برنامهٔ Runtime Role با حداقل GRANT و RLS باید جداگانه بررسی شود.
- schema Spike عمداً فاقد `auth_sessions`, `refresh_tokens`, `business_hours`, `schedule_exceptions` است. از آن ادعای تکمیل اسکیمای محصول نباید کرد.

**Verdict:** `NOT VERIFIED` در سطح عملکرد DB. هیچ Strategy به‌طور تجربی برنده اعلام نشده است.
