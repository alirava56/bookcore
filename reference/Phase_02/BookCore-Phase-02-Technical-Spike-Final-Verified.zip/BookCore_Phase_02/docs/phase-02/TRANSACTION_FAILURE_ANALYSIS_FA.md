> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# تحلیل خطاهای تراکنش و بازآزمایی

## مسیر پیاده‌شده
`transaction()` در `spike/src/db.ts` برای کل Use Case تنها یک `PoolClient` دارد؛ BEGIN در `READ COMMITTED`، timeoutهای Local، Business Mutation و Outbox/Idempotency در همان اتصال، سپس COMMIT. فقط `40P01` و `40001` که قبل از مرحلهٔ COMMIT رخ دهند حداکثر سه بار تلاش می‌شوند. `55P03` قابل بازآزمایی با کلید مشتری است اما blind auto-retry ندارد. `23P01` و `23505` conflict در سطح دیتابیس‌اند و به‌صورت خودکار retry نمی‌شوند.

## عدم قطعیت COMMIT
اگر COMMIT خطای بدون SQLSTATE بدهد، کد `UnknownCommitOutcome` پرتاب می‌کند، اتصال کنار گذاشته می‌شود و **موفقیت ادعا نمی‌شود**. اگر PostgreSQL constraint error با SQLSTATE مشخص در مرحلهٔ COMMIT بدهد، شکست قطعی است. Reissue همان Idempotency Key تنها روش تعیین نتیجه است. این طراحی به تولید مدرک شبکۀ قطع‌شده نیاز دارد.

## fault injection موجود، اما اجرا نشده
- `injectAfter:7` در لغو ۱۵ رزرو، بعد از نوشتن هفت Event خطا می‌اندازد؛ انتظار Rollback همه است.
- Test با `SET LOCAL lock_timeout` انتظار `55P03` دارد؛ Test قفل مخالف انتظار `40P01` دارد.
- Test شبیه‌سازی گم‌شدن پاسخ صرفاً خروجی موفق را دور می‌اندازد و Replay می‌کند؛ **نه آزمون واقعی lost TCP ACK**.
- `40001` ذیل READ COMMITTED به‌صورت طبیعی تضمین‌شده قابل تولید نیست؛ فقط mapping کد بررسی است.

**Evidence:** بدون PostgreSQL همهٔ رفتارهای Runtime `NOT VERIFIED` هستند.
