> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

# Evidence register — Phase 02 remediation

All status labels below refer to actually observed commands, not the intended test suite.

| Check | Observed result | Actual status | Source |
|---|---|---|---|
| Phase 01 baseline provenance | 23 of 23 SHA-256 matches | PASS | `evidence/remediation_command_results.log` |
| Original ZIP missing baseline Manifest | `ENOENT` observed before authentic restoration | REPRODUCED | original untouched ZIP, independent audit |
| Post-restoration static inspection | 3 SQL migrations, 43 `test()` source declarations | PASS (source only) | `evidence/remediation_command_results.log` |
| Empty Node test-module regression | Runner self-test rejects fake success | PASS | `node tools/run_tests.mjs --self-test` |
| Clean source `npm test` | exit 2: compiled tests missing | EXPECTED FAILURE | `evidence/remediation_command_results.log` |
| `npm ci --offline` | exit 1: no lockfile | FAIL | same |
| `npm run typecheck` | exit 2: missing installed Node types | NOT VERIFIED | same |
| `npm run build` | exit 1: missing installed dependencies | FAIL | same |
| TypeScript AST syntax parse | 7 files, zero syntax diagnostics | PASS (syntax only) | `evidence/typescript_syntax_check.log` |
| CI YAML parsing | 1 job parsed, no syntax error | PASS (syntax only) | `evidence/ci_yaml_parse.log` |
| PG migrations | not run, Postgres/Docker unavailable | NOT VERIFIED | environment probe |
| Two-process 100-request capacity (1/20; 3 repetitions) | not run | NOT VERIFIED | no actual metrics |
| Resource exclusion, buffer, branch, history | not run | NOT VERIFIED | no database |
| Idempotency + unknown COMMIT failure | not run | NOT VERIFIED | no database |
| Full session cancel + rollback injection | not run | NOT VERIFIED | no database |
| PostgreSQL SQLSTATE/deadlocks | not run | NOT VERIFIED | no database |
| Actual GitHub Actions workflow | not run | NOT VERIFIED | no push |

**Counts:** 43 static source test declarations; **0 runtime database test executions, 0 runtime pass results**. `npm test` never reached Node's database test suite, so database-runtime discovered/passed/failed/skipped counts are **unknown**, not 43/0/0/0 observed. See `evidence/test_summary.json` for machine-readable information.

Node.js 22.16.0, globally installed TypeScript 5.8.3, Debian GNU/Linux 13; target image PostgreSQL 17.11 but **actual PostgreSQL version not observed**. Existing PostgreSQL benchmarks and real-time latency observations: none.
