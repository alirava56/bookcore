> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# BookCore | Phase 02 — طرح آزمایش فنی و وضعیت اجرا

**مرجع:** Phase 01 v1.1.1، ADR-011 تا ADR-016، TS-01 تا TS-07. این فایل برنامهٔ قابل‌اجرا را توضیح می‌دهد؛ هیچ مورد تعریف‌شده‌ای را با مورد اجراشده اشتباه نمی‌گیرد.

## مرزبندی و زیرساخت
- PostgreSQL `postgres:17.11-bookworm` در `infra/docker-compose.yml` با Healthcheck و نگه‌داری موقتی داده تعریف شده؛ Image pull، راه‌اندازی و Migration در محیط نگارش انجام نشدند.
- TypeScript strict، Node 22.16.0، ابزار `tsc` 5.8.3؛ اتصال دیتابیس از `pg`، `READ COMMITTED`, `FOR UPDATE` و تراکنش واحد برای رویدادها.
- استقرار واقعی لازم نیست؛ دو `child_process.fork` مستقل هرکدام Pool متفاوت دارند و از parent پیام شروع هماهنگ می‌گیرند. این Harness تنها پس از نصب وابستگی و PostgreSQL قابل آزمایش است.
- هویت‌ها Fixture هستند؛ HTTP Authentication/JWT/Refresh در این فاز پیاده نشده‌اند. هر ادعای امنیت API فراتر از scope است.

## ماتریس آزمایش و Evidence موردنیاز
| Spike | کد/تست آماده | شاهد لازم برای PASS | وضعیت واقعی |
|---|---|---|---|
| TS-01 ظرفیت | `spike/tests/spike.test.ts`: ظرفیت 1/20 × 100 × سه بار با دو Process | 1 و 20 رزرو مؤثر، counter برابر COUNT و 99/80 رد بدون خطا، latency توزیعی | NOT VERIFIED |
| TS-02 منابع | GiST `tstzrange`, branch-cross, midnight, buffer, cancellation | مشاهده 23P01، پذیرش adjacency و حفظ تاریخچه | NOT VERIFIED |
| TS-03 ORM | معیارهای comparison در `ORM_EVALUATION_FA.md` | اجرای Prisma/Drizzle یا انتخاب SQL-first با evidence | NOT VERIFIED |
| TS-04 ابطال مجوز | race در `Security` tests، CancelAll | روایت واقعی lock order و atomic commit در PG | NOT VERIFIED؛ Refresh خارج از پیاده‌سازی |
| TS-05 Idempotency | Claim+Final در یک TX؛ بازپخش هم‌زمان، رد پایدار، شبیه‌سازی lost response | no duplicate side effects و بازیابی واقعی ambiguous commit | NOT VERIFIED |
| TS-06 integrity | Deferred constraint triggers + metadata guard + reconciling | raw invalid writes abort at commit، بدون deadlock غیرقابل‌کنترل | NOT VERIFIED |
| TS-07 migrations / restore / timezone | نسخه‌های SQL و طراحی UTC | اجرای migration clean، backup/restore drill و DST validation | NOT VERIFIED؛ خارج از Spike فعلی |

## رویهٔ آزمون واقعی
1. Docker Compose، PostgreSQL version، extensions و Image digest را ثبت کنید.
2. `npm install` متکی به registry را اجرا و قفل وابستگی معتبر تولید کنید؛ آنگاه `npm ci` را از workspace تازه تأیید کنید.
3. `npm run typecheck`, `npm run lint`, `npm run build`, `npm run migrate` و تست‌ها را اجرا کنید.
4. نتایج SQLSTATE، تعداد موفق/رد/Timeout، durations، p50/p95/p99 و وضعیت Pool را ثبت کنید.
5. اجرای چندباره، fault injection و drift detection را از روی دیتابیس جداگانه تأیید کنید.
6. قبل از PASS، موارد ناشناخته مثل فاز زمان‌بندی، محدودیت Write نقش Runtime، خطای Commit ناشناخته و backup/restore را تعیین تکلیف کنید.

**Status:** طراحی آزمایش و سورس ساخته شد؛ اجرای آزمون‌های وابسته به PostgreSQL مسدود است.
