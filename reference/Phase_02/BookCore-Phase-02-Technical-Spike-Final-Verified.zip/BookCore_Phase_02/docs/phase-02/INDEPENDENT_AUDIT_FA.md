> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

# ممیزی مستقل اصلاحی BookCore Phase 02

**دامنه:** سورس بستهٔ اصلی Phase 02؛ migration، TypeScript، worker، تست‌ها، CI و منابع فاز اول. **وضعیت:** اصلاحات کد اعمال شده‌اند؛ اثبات PostgreSQL هنوز انجام نشده است. تاریخ ممیزی: 2026-11-22.

**SHA-256 بستهٔ اصلی بدون تغییر:** `8f6cf770a05e6e95227e3eb5bb048f1fbf56dcbaeae1c71019d17239454ededa`.

## یافته‌ها و اصلاحات

| شناسه | نقص بازبینی‌شده | اصلاح واقعی | اثبات مستقل موجود | وضعیت |
|---|---|---|---|---|
| B-01 | نبود اجرای PostgreSQL و ادعای اثبات‌ناشدهٔ invariantها | Docker Compose نسخهٔ 17.11 حفظ، CI و تست‌های توسعه‌یافته آماده شد | `docker`, `postgres`, `psql` در محیط موجود نیستند؛ هیچ SQL اجرا نشد | NOT VERIFIED |
| B-02 | نبود package-lock و Type Shim آزمایشی | Type Shim در بستهٔ اصلاحی حضور ندارد؛ `npm ci` بدون Lockfile عمداً شکست می‌خورد | `npm ci --offline --ignore-scripts` → EUSAGE؛ `npm view` → EAI_AGAIN | FAIL |
| B-03 | `static_checks.mjs` به Manifest غایب ارجاع می‌دهد | Manifest اصیل نسخهٔ اول از `BookCore-Phase-01-Engineering-Final.zip` بازیابی و بدون تغییر کپی شد | خطای `ENOENT` روی بستهٔ اصلی بازتولید؛ ۲۳/۲۳ SHA تأیید و Static Check موفق | PASS (فقط این نقص) |
| B-04 | Test Runner می‌توانست بدون تست مؤثر موفق شود | Runner مستقل صریح، حداقل تست، بررسی گزارش TAP و تعداد فراخوانی‌های `test()`، خروج غیرصفر برای صفر تست | `node tools/run_tests.mjs --self-test` PASS، آزمون واقعی فایل خالی در Process مجزا FAIL شد؛ `npm test` بدون Build exit=2 | PASS (فقط Runner) |
| B-05 | توقف نامطمئن worker و IPC | Worker پس از `pool.end()` نتیجه می‌فرستد و IPC را disconnect می‌کند؛ Parent تا دریافت دو exit=0 منتظر می‌ماند و Timeout/Kill دارد | Source/Syntax check موفق؛ **Process+DB runtime هنوز تست نشده** | NOT VERIFIED |
| B-06 | Drift از تغییر Session/Tenant در FKها و Triggerهای Deferred | `003_hardening.sql`: منع reparent/delete، کنترل وضعیت Session/Booking، کنترل event history، بررسی OLD و NEW، serialization تغییر منابع | ۱۲+ negative/adversarial test اضافه، ولی **هیچ‌کدام روی PG اجرا نشده‌اند** | NOT VERIFIED |

## نقایص افزودهٔ قطعی در بازبینی کد

1. **COMMIT unknown:** `db.ts` پیشین هر Error دارای `code` را SQLSTATE نهایی می‌انگاشت. خطای Socket مانند `ECONNRESET` نیز `code` دارد؛ نسخهٔ جدید برای ابطال قطعی علاوه بر SQLSTATE، `severity` سرور را می‌طلبد و وضعیت مبهم را با `UnknownCommitOutcome` جدا می‌کند. تست واقعی قطع اتصال هنوز لازم است.
2. **Drift مهاجرت:** Migrator قبلی فقط نام فایل‌ها را ثبت می‌کرد و تغییر محتوای SQL پس از اجرای قبلی را تشخیص نمی‌داد. اکنون `checksum_sha256` و `MIGRATION_DRIFT` دارد و اجرای دوم روی همان دیتابیس طراحی شده است. روی PG آزمایش نشده.
3. **تخریب تاریخچه:** `bookings` و `resource_allocations` بدون محافظ کافی برای DELETE و جابه‌جایی aggregate بودند. گاردهای BEFORE و بررسی Deferred تکمیل شدند؛ زمان Commit هنوز بررسی نشده.
4. **رقابت Buffer/Allocation:** FK تنها KEY SHARE ایجاد می‌کند و با NO KEY UPDATE روی Buffer تضاد کافی ندارد. Trigger جدید روی Allocation، Resource را `FOR SHARE` قفل می‌کند تا تغییر متادیتا با ایجاد Allocation serialize شود. آزمایش دو اتصال واقعی باز است.
5. **تست midnight خلاف domain:** آزمون قبلی زمان یک Session منتشرشده را مستقیماً تغییر می‌داد؛ Fixture جدید Session آیندهٔ نیمه‌شب می‌سازد و invariant رزرو معتبر را نمی‌شکند.
6. **ادعای تست‌پذیری کاذب:** Node تست‌رانر یک فایل Test خالی را ممکن است به‌عنوان «۱ تست موفق» گزارش کند؛ اصلاح جدید وجود فراخوانی صریح `test()` را بررسی می‌کند.

## یافته‌های باز و ریسک‌های باقیمانده

- SQL 003 با PostgreSQL واقعی parse و اجرا نشده است؛ Syntax Source Scan نمی‌تواند جایگزین catalog/constraint testing باشد.
- ممکن است هنگام اجرای آزمایش‌ها، ترتیب Lock یا Deferred Triggerها نیازمند اصلاح شود. تا آن زمان هیچ invariant به‌صورت اجرایی اثبات نشده است.
- `booking_events` برای تغییر Booking با SQL Trigger بررسی می‌شود، ولی نقش‌های DML و مجوز مستقیم INSERT به تاریخچه هنوز نیازمند verification و محدودسازی عملیاتی هستند.
- Retention و پاک‌سازی Idempotency، حد واقعی pool/lock latency، retries و lost acknowledgement فقط در سناریوها تعریف شده‌اند.
- این Spike سرویس تولیدی RBAC/JWT نیست و نقش DBA با نقش اپلیکیشن یکسان نباید باشد. PostgreSQL و CI با credentials محلی تست و نه production تعریف شده‌اند.
- Package-lock معتبر، نصب نوع‌های واقعی و CI سبز هنوز **وجود ندارند**. هیچ GitHub workflow اجرا نشده است.

## نتیجهٔ مستقل

**فقط اشکالات Source/Packaging قابل آزمون استاتیک اصلاح و تأیید شدند.** هیچ PASS برای correctness مبتنی بر پایگاه داده مجاز نیست؛ Phase 02 همچنان FAIL است. جزئیات Gateها در گزارش نهایی آمده‌اند.
