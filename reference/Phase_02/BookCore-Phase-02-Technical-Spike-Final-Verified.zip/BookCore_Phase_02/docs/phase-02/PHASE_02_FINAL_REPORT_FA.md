# BookCore — گزارش نهایی اجرای واقعیِ تلاش‌شده و Release Gate فاز دوم

**تاریخ:** ۲۰۲۶-۱۱-۲۲  
**منبع معتبر:** آرشیو `BookCore-Phase-02-Technical-Spike-Verified.zip` با SHA-256 برابر `45baabb184e0dcb0bd87109c5edb2cd2bc8fcb3679739c9de7bf6205100ed89c`  
**خروجی:** نسخهٔ مستقل اصلاح‌شده؛ منبع اصلی بدون تغییر در `reference/original_phase02_verified/` نگهداری شده است. فاز سوم آغاز نشده است.

## نتیجهٔ اجرایی

**این محیط امکان اجرای PostgreSQL 17 و نصب واقعی پکیج‌های npm را ندارد.** در نتیجه هیچ تست PostgreSQL، Migration یا Concurrency در این نشست PASS نشده است؛ نمی‌توان معماری را معتبر اعلام کرد. برخلاف انتظار کارفرما، بستهٔ نهایی هنوز `package-lock.json` واقعی ندارد، زیرا npm Registry با خطای `EAI_AGAIN` در دسترس نبود. تولید Lockfile دستی، ادعای نصب موفق یا ثبت داده‌های ساختگی عمداً انجام نشده است. عبارت «Final-Verified» در نام فایل، نام خروجی درخواستی است و به معنی تأیید فنی نیست.

## اقدامات انجام‌شده بر اساس سورس قابل‌بررسی

- نسخهٔ مرجع را مستقل استخراج کردیم؛ **۶۹/۶۹** هش فایل‌های Manifest اولیهٔ Phase 02 Verified و سلامت ZIP مطابقت داشتند. SHA کامل در بالا است.
- هر سه Migration قدیمی بدون تغییر حفظ شدند و Migration **`004_history_consistency.sql`** با Triggerهای محافظت از ثبت رویداد، ترتیب منطقی Event، سازگاری Cancel Reason و انجماد داده‌های نهایی اضافه شد.
- مشکل قابل‌تأیید درج `BookingEvent` بدون بررسیِ مستقل در COMMIT و مشکل قابل‌تأیید دستکاری Cancellation Metadata اصلاح کد شدند.
- `verify_booking_history` به جای فقط «آخرین Event»، کل زنجیره را کنترل می‌کند؛ Trigger تعویقی روی **INSERT** Event آن را بررسی می‌کند. قفل Session قبل از Booking در این مسیر حفظ شده است.
- ۱۲ تست جدید **H01–H12** برای SQL نامعتبر، Event جعلی، Cancellation Metadata، تاریخچه و Reconciliation نوشته شدند؛ این تست‌ها **اجرا نشده‌اند**.
- در `db.ts` خطاهای `FATAL`/`PANIC` در زمان COMMIT دیگر به‌اشتباه abort قطعی تلقی نمی‌شوند؛ آن‌ها Unknown Commit هستند و بازیابی باید با همان Idempotency-Key انجام شود.
- Reconciliation جدید علاوه بر ظرفیت و Allocation، Drift تاریخچهٔ Booking را در Query جداگانه جست‌وجو می‌کند.
- آستانهٔ Runner به حداقل ۵۵ تست پیش‌بینی‌شده تغییر کرد؛ در سورس ۵۵ فراخوانی `test(...)` وجود دارد، که یک حلقهٔ دوحالته باید ۵۶ تست در Runtime بسازد. **تعداد واقعی کشف‌شده هنوز نامعلوم است.**
- ADR-019 و ممیزی مستقل نهایی به Package اضافه شدند. کد CI تهیه شده ولی **GitHub Actions اجرا نشده** است.

**یادآوری:** تغییر SQL و تهیهٔ تست رگرسیون «اصلاح در سورس» است، نه اثبات صحت آن. ممکن است آزمایش واقعی ایرادهای جدیدی را نشان دهد.

## محیط واقعی و فرمان‌های اجراشده

| بررسی | فرمان | خروج واقعی |
|---|---|---|
| Node / npm | `node -v`; `npm -v` | v22.16.0 / 10.9.2 |
| Docker / PostgreSQL | `command -v docker`; `command -v psql`; `command -v postgres` | هیچ‌یک در PATH موجود نبود |
| تولید Lockfile معتبر | `npm install --package-lock-only --ignore-scripts --fetch-retries=0 --fetch-timeout=6000 --no-audit --no-fund` | **FAIL**، `EAI_AGAIN registry.npmjs.org` |
| نصب تمیز | `npm ci --ignore-scripts --offline` | **FAIL**، `package-lock.json` وجود ندارد |
| Typecheck واقعی | `npm run typecheck` | **FAIL**، `TS2688` نبود `@types/node` |
| Build واقعی | `npm run build` | **FAIL**، انواع `node` و `pg` نصب نشده‌اند |
| Test Suite واقعی | `npm test` | **FAIL CLOSED**، پوشهٔ `dist/tests` وجود ندارد؛ دیتابیس تست نشده |
| اجرای Migration | `npm run migrate` | **FAIL**، فایل خروجی Build وجود ندارد |
| اجرای Reconciliation | `npm run reconcile` | **FAIL**، فایل خروجی Build وجود ندارد |
| Static lint پروژه (Domain-specific؛ نه ESLint) | `npm run lint` | **PASS**؛ فقط Static Checks و Zero-Test Regression، نه تحلیل معنایی TypeScript |
| بررسی منابع | `python tools/verify_reference.py` | **PASS**، ۲۳ هش مرجع فاز اول |
| بررسی منبع/قواعد استاتیک | `node tools/static_checks.mjs` | **PASS**، چهار فایل Migration در منبع شناسایی شدند |
| Zero-Test Runner | `node tools/run_tests.mjs --self-test` | **PASS**، خروج کاذب ۰ تست رد شد |
| Syntax TypeScript | Parse هفت فایل با TypeScript v5.8.3 جهانی | **PASS**، ۰ خطای Parse؛ **نه Typecheck** |
| اسکریپت‌های Node | `node --check tools/*.mjs` (به تفکیک) | **PASS** |
| CI Workflow YAML | `python -c 'import yaml; yaml.safe_load(...)'` | **PASS** فقط parse، نه اجرای CI |

**منبع شواهد:** فایل‌های واقعی `evidence/final/*.log` و `evidence/final/test_summary.json`. هیچ latency، throughput، شمارندهٔ موفقیتِ PostgreSQL، SQLSTATE اجرایی یا نتیجهٔ Worker تولید نشد. «۰ تست دیتابیسی اجراشده» به معنی «صفر نقص» نیست.

## هشت Gate اجباری

| Gate | وضعیت | شاهد واقعی | محدودیت |
|---|---|---|---|
| G1 — PostgreSQL Setup / Migration | **NOT VERIFIED** | ابزارها موجود نیستند؛ اجرای Migration شکست خورد | PostgreSQL 17 راه‌اندازی نشده |
| G2 — Database Integrity | **NOT VERIFIED** | SQL و تست منفی جدید نوشته شده‌اند | Commit نادرست روی دیتابیس واقعی رد نشده است |
| G3 — Capacity Concurrency | **NOT VERIFIED** | Harness دوپردازشی در سورس موجود است | ظرفیت ۱/۲۰ و سه تکرار واقعی = صفر |
| G4 — Resource Exclusion | **NOT VERIFIED** | تعریف `btree_gist`/`tstzrange` در Migration | Overlap و Buffer اجرا نشده است |
| G5 — Idempotency & Unknown Commit | **NOT VERIFIED** | طبقه‌بندی FATAL اصلاح شده، تست‌های نظری وجود دارند | هیچ اتصال واقعی قطع و بازیابی نشده |
| G6 — Cancellation Atomicity | **NOT VERIFIED** | تست لغو ۱۵ نفر و Rollback در سورس | هیچ رکورد واقعی بررسی نشده |
| G7 — Committed-State Enforcement | **NOT VERIFIED** | Deferred Trigger و Query تاریخچه نوشته شده‌اند | SQL در PostgreSQL 17 آزمایش نشده |
| G8 — Clean-room Reproducibility | **FAIL** | `npm ci` شکست خورد، Build و تست شروع نشد | Lockfile اصیل و اتصال رجیستری در دسترس نیستند |

## ملاحظات مهندسی باز

1. **ریسک Deadlock:** قفل‌های جدیدِ Deferred روی Session و Booking در فشار واقعی، باید با PostgreSQL 17 و حداقل ۱۰۰ درخواست هم‌زمان آزمایش شوند. تنها «تبعیت موردنظر از ترتیب قفل» از روی سورس استنباط شده است.
2. **تاریخچهٔ موجود:** هنگام اعمال Migration 004 به دیتابیس حاوی داده، backfill شناسهٔ ترتیبی به‌تنهایی ترتیب تاریخی را تضمین نمی‌کند. باید Backfill مستقل و ممیزی پیش از پذیرش Migration انجام شود.
3. **دسترسی مستقیم SQL:** یک Database Owner با امکان تغییر سازگار چند جدول می‌تواند قواعد تجاری را دور بزند. کنترل دسترسی نقش اپلیکیشن و Stored Functions یا API Authorization هنوز برای محصول لازم است؛ Triggerها جایگزین RBAC نیستند.
4. **Unknown COMMIT:** خطای `FATAL` و خطای شبکه هنگام COMMIT باید به recovery با Idempotency-Key منجر شود. آزمایش واقعی lost-ack انجام نشده است.
5. **ORM و CI:** Prisma/Drizzle و GitHub Actions اجرا نشده‌اند. Workflow معتبر بودن YAML به معنی CI سبز نیست.
6. **فایل Lock:** باید روی سیستم متصل با npm واقعی تولید شود؛ به Package کنونی اضافه نشده است و نبود آن نقص اصلی Release باقی می‌ماند.

## فرمان‌های دقیق اپراتور روی سیستم دارای اینترنت و Docker

```bash
# در ریشه BookCore_Phase_02 از ZIP استخراج‌شده
cd spike
npm install --package-lock-only --ignore-scripts --no-audit --no-fund
npm ci --ignore-scripts
npm run typecheck
npm run lint
npm run build
cd ..
docker compose -f infra/docker-compose.yml up -d --wait
cd spike
npm run migrate
npm run migrate
BOOKCORE_MIN_TESTS=56 npm test
npm run reconcile
cd ..
docker compose -f infra/docker-compose.yml down --volumes
```

قبل از هر PASS، خروجی `SHOW server_version_num` باید نسخهٔ اصلی ۱۷، `spike_migrations` دقیقاً چهار فایل با SHA تطبیق‌شده، شش Run ظرفیت در دو Process همراه خروج سالم Worker، و Reconciliation بدون Drift را **واقعاً** نشان دهد. برای اجرای دقیق‌تر می‌توان اسکریپت `tools/run-local.sh` را بعد از تولید Lockfile به‌کار برد. Test Evidence و JSON باید بر اساس اجرای مشاهده‌شده تکمیل شوند، نه از روی تعداد تعریف‌ها.

## حکم نهایی

`TECHNICAL-SPIKE-FAIL — ARCHITECTURAL BLOCKERS REMAIN`

تا زمانی که **تمام هشت Gate با شواهد واقعی PASS نشده‌اند**، آغاز Phase 03 توصیه یا تأیید نمی‌شود. هیچ ادعای Production Readiness یا اجرای موفق PostgreSQL نشده و چیزی به GitHub ارسال نشده است.
