> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# مرزهای امنیتی و Tenant Integrity

## کنترل‌های طراحی‌شده در سورس
Composite FK برای Session/Booking/Allocation از اتصال رکورد بین Tenantها جلوگیری می‌کند. `booking_events` و `audit_events` append-only در trigger طراحی شده‌اند. Body/actor از Web Request وجود ندارد؛ توابع داخلی فقط Fixtureهای آزمایشی را می‌پذیرند. `checkActor` وضعیت User، Organization و برای عملیات Manager عضویت فعال را داخل TX با `FOR SHARE` می‌خواند؛ Revocation با UPDATE در همان Row قفل ناسازگار دارد. تست Cross-Tenant و Race Revocation نوشته شده است.

## مرزهای روشن
- این تست‌ها **RBAC End-to-End نیستند**: JWT، AuthSession، Refresh replay، هویت‌سنجی Customer واقعی، BOLA در HTTP و CSRF اجرا/پیاده نشده‌اند.
- توابع ساده‌شدهٔ Spike فقط رزرو Self و مدیریت توسط Owner/Manager را پشتیبانی می‌کنند؛ عملیات Receptionist و Trainer Attendance مطابق Phase 01 هنوز خارج از scope است.
- DB default user در Docker Compose برای تست توان بالایی دارد؛ نقش Readonly آزمایشی فقط با یک Negative Test محدود بررسی می‌شود؛ سیاست نهایی Runtime DB Grants و مهاجرت نقش‌ها تعیین نشده است.
- صدور `operation` در توابع Spike از کانتکست داخلی test harness است؛ در HTTP واقعی باید ثابت و Server-derived باشد. نه کلید و نه `tenantId` ارسال‌شده از سمت مشتری نباید مجوز تلقی شود.
- دادهٔ اصلی، توکن یا Credential واقعی وارد بسته نشده است. رمز پیش‌فرض Compose **صرفاً مثال disposable local** است.

**Runtime security testing:** `NOT VERIFIED`. Database FK جایگزین policy authorization نیست.
