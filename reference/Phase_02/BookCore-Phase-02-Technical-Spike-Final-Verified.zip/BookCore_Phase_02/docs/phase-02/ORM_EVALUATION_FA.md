> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# Prisma / Drizzle — ارزیابی محدود به طراحی و کد SQL مستقیم

| معیار BookCore | Prisma | Drizzle | شاهد قابل‌اتکا این فاز |
|---|---|---|---|
| GiST exclusion و `btree_gist` | Migration SQL سفارشی | Migration SQL سفارشی | فقط SQL نوشته‌شده |
| Partial UNIQUE / composite FK | SQL سفارشی و بررسی Catalog | SQL سفارشی و بررسی Catalog | فقط SQL نوشته‌شده |
| `FOR UPDATE` یک‌اتصالی | باید با interactive TX تست شود | باید با transaction/sql تست شود | هیچ تست ORM نصب نشد |
| SQLSTATE 23P01/23505/40P01 | به Adapter وابسته | به Adapter وابسته | Mapping مستقیم `pg` صرفاً کامپایل شد |
| Migration drift / حفظ native SQL | نیازمند کنترل مستقل | نیازمند کنترل مستقل | NOT VERIFIED |
| تایپ‌ها، Developer Experience و Pool | باید آزموده شود | باید آزموده شود | NOT VERIFIED |

**دلیل عدم تست:** رجیستری npm و اتصال خارجی محیط نگارش در دسترس نبود؛ به جای جعل Benchmark، Spike با `pg` و SQL صریح نوشته شد. تصمیم موقت ADR-016 برای انتخاب Drizzle **تأیید نهایی نیست** و تغییر نکرده است. Spike بایستی بعد از دسترسی به ابزارها SQL migrations را با هر ORM در یک TX نمونهٔ کوچک آزمایش کند، نه کل برنامه را دو بار بنویسد.

**Verdict ORM:** `NOT VERIFIED`؛ انتخاب قطعی ممنوع.
