> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

# گزارش بازتولیدپذیری — Phase 02 remediation

**نتیجه: FAIL — اجرای تمیز کامل مقدور نبود.**

| بررسی | دستور اجراشده | مشاهدهٔ واقعی | قضاوت |
|---|---|---|---|
| هش بستهٔ فاز اول | `python tools/verify_reference.py` | `PASS Phase01 SHA256 23/23` | PASS |
| Inspection استاتیک | `node tools/static_checks.mjs` | ۳ Migration، ۴۳ تست تعریف‌شده، بررسی متنی و ۲۳ هش، خروج ۰ | PASS (محدود) |
| رگرسیون Zero Tests | `node tools/run_tests.mjs --self-test` | یک فایل تست کامپایل‌شدهٔ خالی در فرآیند مستقل بررسی و توسط Runner رد شد | PASS |
| اجرای اولیه تست از سورس بدون Build | `cd spike && npm test` | پیام `compiled test directory missing` و کد خروج ۲ | PASS برای failure behavior؛ تست DB اجرا نشد |
| نصب قابل بازتولید | `cd spike && npm ci --offline --ignore-scripts` | کد خروج ۱، Lockfile معتبر وجود ندارد | FAIL |
| دسترسی Registry | `npm view pg@8.16.3 dist.integrity --fetch-retries=0 --fetch-timeout=5000` | خطای `EAI_AGAIN` | BLOCKED |
| Typecheck وابستگی‌های واقعی | `cd spike && npm run typecheck` | کد خروج ۲: نوع‌های Node نصب نیست | NOT VERIFIED |
| Build | `cd spike && npm run build` | کد خروج ۱: `pg` و Node Types نصب نیست | FAIL (prerequisite) |
| Source parse TS | TypeScript 5.8.3 `createSourceFile` روی ۷ فایل | ۰ syntax diagnostics | PASS (syntax only) |
| CI YAML | PyYAML `safe_load` | یک Job، بدون خطای YAML | PASS (parse only) |
| PostgreSQL | بررسی `docker`, `postgres`, `psql` | هر سه غیرموجود | NOT VERIFIED |
| Clean ZIP extraction | تست انتهایی بسته‌بندی | در `evidence/clean_archive_validation.log` ثبت می‌شود | نتیجه در آن فایل |

**مهم:** هیچ `package-lock.json` جعلی تولید نشده است. `npm ci` در CI به‌درستی تا وقتی dependency resolution واقعی انجام نشود شکست خواهد خورد. نتیجهٔ اجرای موفق Source Scan یا Parser به معنی تأیید SQL، خروج worker، تست تراکنش یا throughput نیست.
