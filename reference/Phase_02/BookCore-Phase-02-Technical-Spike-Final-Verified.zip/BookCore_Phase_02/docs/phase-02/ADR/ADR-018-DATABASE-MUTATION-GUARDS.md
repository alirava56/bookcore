# ADR-018 — Database mutation identity guards and commit uncertainty

**Status:** PROPOSED — CODE IMPLEMENTED, RUNTIME NOT VERIFIED (2026-11-22).

## Decision

1. Reject Booking/Allocation reparenting and DELETE as immutable identity/history transitions; do not rely on verifying only NEW aggregate at commit.
2. For the canonical mutation paths, use explicit SQL, `READ COMMITTED`, ordered Session locks, deferred consistency checks and append-only event history. Add checked transition guards and a deferred `verify_booking_history` check.
3. Lock Resource `FOR SHARE` during allocation writes to serialize their committed buffers with resource metadata changes, which otherwise may take compatible row lock modes.
4. Record every migration SHA-256 at application time; fail on an altered applied migration. Do not auto-reconcile schema drift.
5. Treat a COMMIT response lost at network level as `UnknownCommitOutcome` and never silently retry; client must recover by original idempotency key. A server-returned PostgreSQL error with severity+SQLSTATE is a known abort, permitting only bounded safe retries.

## Rationale

The original deferred-check function only inspected the NEW side of an UPDATE; moving a Booking to another Session could leave an old aggregate inconsistent. Immutable FK identities and old/new verification remove that class of bypass by design. Likewise `ON DELETE` should preserve historical records. Direct SQL must be rejected by the database, not by application convention alone.

## Tradeoffs / remaining technical risk

Extra triggers and row locks increase contention and require real PostgreSQL deadlock/performance experiments. Event sorting by `at` and UUID tie-breakers must be verified under tight concurrency. Schema-level authorization remains distinct from production HTTP RBAC/JWT. Migration 003 is not yet executed; this ADR must not be treated as proven until negative tests, multi-process tests and PG catalog inspection pass.

## Verification criteria

All B-06 regressions must fail their deliberate bad SQL writes with deterministic server SQLSTATE; valid transaction workflows must commit without drift; resource-buffer races must be serialized; no orphan worker remains. G1–G8 require observed evidence rather than source assertions.
