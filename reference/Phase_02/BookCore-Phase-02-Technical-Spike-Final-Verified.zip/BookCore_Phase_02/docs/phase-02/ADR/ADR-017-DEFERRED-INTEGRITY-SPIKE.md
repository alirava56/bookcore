# ADR-017 — Deferred integrity trigger candidate (Phase 02)

- **Status:** PROPOSED — runtime verification pending; does NOT supersede Phase 01 ADR-011/016.
- **Context:** Session counter versus COUNT(effective Booking) and active/interval ResourceAllocation invariants are not row-level CHECK constraints. A restricted role + asynchronous reconciliation alone would allow incorrect commits if write privilege leaks.
- **Spike implementation:** `001_core.sql` uses `CONSTRAINT TRIGGER DEFERRABLE INITIALLY DEFERRED` on Session, Booking and Allocation plus `SELECT ... FOR UPDATE` on Session, and on IdempotencyRecord to forbid committed `PROCESSING`. `002_resource_guard.sql` prevents modifying allocated Resource buffers/identity. Reads across `bookings` and `resource_allocations` evaluate the final transaction state. Booking mutations hold Session lock first per ADR-011.
- **Pros:** erroneous direct single-row mutations should abort at COMMIT, rather than being silently reconciled later. Makes invalid test mutations possible.
- **Costs/risks:** per-row trigger overhead, lock-order interaction, event history completeness, complexity of updates touching multi-Session aggregates, concurrent phantom/write-skew under noncooperative transactions. No real migration or contention test has run.
- **Alternatives for next investigation:** narrowly granted runtime role + trusted stored procedures and independent reconciliation; deferred trigger plus restricted role (possibly combined); detection-only reconciliation (insufficient as primary guarantee).
- **Decision rule:** accept only if observed PG tests demonstrate commit-time enforcement without dangerous deadlocks under documented load, and if operational cost is acceptable. If not, revise schema/transaction boundary via a new ADR without weakening the domain invariants.
- **Status of evidence:** TypeScript static checks only; SQL parser/PG execution NOT VERIFIED.
