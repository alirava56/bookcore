# ADR-019 — Transactional BookingEvent chain and immutable terminal metadata

**Status: PROPOSED / NOT VERIFIED on PostgreSQL 17** (2026-11-22)

## Context

The Phase 02 candidate guarded `booking_events` against UPDATE/DELETE, but did not
check a standalone `INSERT` at commit. `verify_booking_history()` compared only the
latest event using `(at,id)`, so an extra event with attacker-selected timestamp
could remain committed without updating `bookings.status`. It also allowed changes
to cancellation metadata once a Booking/Session was cancelled.

## Decision for the technical spike

1. Migration `004_history_consistency.sql` introduces server-generated `event_order`
   and overrides a supplied `at` value on INSERT. Historical order is by the logical
   integer sequence, not by wall clock or UUID. Event rows remain append-only.
2. A `BEFORE INSERT` guard validates supported transitions, and a **deferred**
   `AFTER INSERT` constraint trigger independently validates the entire event chain
   against the authoritative Booking state. New events cannot escape verification
   merely because Booking was not updated.
3. Booking states `CANCELLED`, `ATTENDED` and `NO_SHOW` are terminal and immutable.
   `CANCELLED` and `FINISHED` Sessions are immutable. Cancel reasons must be nonblank
   when required and may not subsequently change.
4. An inactive allocation is historical; retrospective mutations are forbidden.
5. The event verifier first locks Session through `verify_session_integrity`, then
   Booking, matching the intended lock order of application writes. PostgreSQL
   deadlock and load consequences have NOT been measured.
6. Reconciliation includes a separate persisted-data query for history drift.

## Assumptions and limitations

- On a populated database, adding an IDENTITY column does **not** prove that
  backfilled order matches historical event occurrence. Migration includes
  validation of all existing chains and will abort on mismatches; manual migration
  planning is required before production adoption.
- Database owner/superuser can still bypass protections. Spike's fixture role is
  **not** equivalent to production service permissions.
- A user with authorized direct DML access to **all** domain tables could still
  manufacture a fully consistent state transition. Production should expose
  controlled transaction functions or restrict table DML. This architectural
  boundary remains an OPEN DECISION and may be a design blocker.
- IDENTITY increments can have gaps and do not encode global commit order.
- No PostgreSQL runtime test has been executed in this environment. Syntax,
  constraint ordering, deadlock behavior and performance remain NOT VERIFIED.

## Alternatives and trade-offs

| Alternative | Benefit | Cost / rejection |
|---|---|---|
| Latest-event equality only | Cheap | Fails to reject forged standalone events |
| Latest-event time ordering | Easy query | Clock and client input can reorder history |
| Full per-Booking chain validation | Stronger committed-state integrity | Additional reads, locking, performance risk |
| DB-only stored procedures plus no DML grants | Stronger authorization boundary | Increased operational complexity, pending spike |

## Acceptance criteria

- PostgreSQL rejects H01–H06, H09–H10 invalid changes and retains preexisting rows.
- H07/H08 prove immutable logical ordering and correct transitions.
- H11 validates authentic migration checksum; H12 verifies independent reconciliation.
- All original capacity, cancellation and deadlock tests still pass in real PG17.
- Repeated clean migrations succeed; checksum drift fails closed.

**Verification:** Tests have been authored but **none executed on PostgreSQL**.
