> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# منابع و زمان‌بندی — Test Matrix

`resource_allocations` با GiST/`btree_gist` روی `(tenant_id,resource_id,tstzrange(start_at,end_at,'[)'))` و predicate `active` تعریف شده است. Buffer در جدول تخصیص به بازهٔ Instant اضافه می‌شود؛ Session UX interval اصلی را حفظ می‌کند. جداول Trainer Resource tenant-wide هستند؛ یک Trainer در شعب یک Tenant تداخل را دور نمی‌زند.

| Test | ورودی/شرط | انتظار | نتیجهٔ واقعی |
|---|---|---|---|
| C1 | هم‌پوشانی Trainer | 23P01 و Rollback | NOT VERIFIED |
| C2 | Session مجاور با Buffer=0 | پذیرش هر دو | NOT VERIFIED |
| C3 | ۱۰ دقیقه Buffer قبل و بعد | adjacency رد، فاصلهٔ مناسب قبول | NOT VERIFIED |
| C4 | Trainer و Room متمایز | عدم تداخل کاذب | NOT VERIFIED |
| C5 | Trainer واحد در دو Branch | 23P01 | NOT VERIFIED |
| C6 | Session CANCELLED و Allocation غیرفعال | امکان Session تازه همان بازه، حفظ تاریخچه | NOT VERIFIED |
| C7 | 23:30→00:30 UTC | مقایسهٔ instant مستقل از تاریخ محلی | NOT VERIFIED |

**حد اثبات:** ساعت کاری، Exceptionهای زمان‌بندی، DST offset↔IANA و Resource از دو Tenant در سناریوی قرارداد زمان‌بندی برنامه‌ریزی شده‌اند ولی Spike فعلی در سطح کامل پیاده‌سازی‌شان نکرده است. `timestamptz` به‌تنهایی اعتبارسنجی IANA ورودی API را انجام نمی‌دهد.
