> **الحاقیهٔ نهایی ۲۰۲۶-۱۱-۲۲:** بعد از این گزارش نسخهٔ 004 و تست‌های H01–H12 اضافه شده‌اند. برای تعداد فایل‌ها، اجرای واقعی فرمان‌ها و آخرین حکم Gateها، `PHASE_02_FINAL_REPORT_FA.md` و `evidence/final/` مرجع نهایی‌اند. نتایج قبلیِ صرفاً استاتیک به معنای PASS دیتابیس نیستند.

> **نسخهٔ اصلاحی B-01..B-06:** این گزارش بخشی از تحویل اولیهٔ Phase 02 است و بخش‌هایی از آن وضعیت پیش از Remediation (۲۷ تست و ۲ Migration) را ثبت می‌کند. برای وضعیت جاری و نتایج واقعاً اجراشده، `INDEPENDENT_AUDIT_FA.md`، `TEST_EVIDENCE.md` و `PHASE_02_FINAL_REPORT_FA.md` را مرجع قرار دهید. هیچ تست PostgreSQL در این تحویل جدید اجرا نشده است.

# Idempotency — طراحی و محدودیت اثبات

قرارداد Phase 01 (ADR-012) بدون تغییر اجرا شده است: کلید composite `(tenant_id,actor_id,operation,key)`، canonicalization محدود JSON و SHA-256 از Method+concrete path+body، `PROCESSING` فقط داخل TX، سپس `FINAL` با پاسخ `2xx/4xx` و COMMIT. `ON CONFLICT DO NOTHING` منتظر پایان درج رقیب می‌ماند؛ درخواست دوم پس از Commit، Hash را مقایسه و پاسخ اصلی را بازمی‌گرداند. اختلاف Hash → 409، شکست DB → Rollback بدون ثبت پاسخ 5xx.

Testهای نوشته‌شده: تکرار هم‌زمان، Hash متفاوت، رد `SESSION_FULL` پایدار، replay رکورد منقضی ولی نگه‌داری‌شده، و replay پس از discard ساختگی پاسخ. در بازپخش، Business Event جدید صادر نمی‌شود.

**شکاف‌های اجرایی:** آزمایش cleanup واقعی، ورود هم‌زمان Key بعد از Cleanup و اتصال گم‌شده در لحظهٔ COMMIT هنوز کد کامل/اجرای واقعی ندارند. canonicalizer فعلی برای زیرمجموعهٔ JSON ورودی طراحی شده و ادعای پیاده‌سازی کامل RFC 8785 ندارد. کنترل input schema و Operation ID باید در API واقعی ثابت و Server-owned باشد. `AuthSession` و real Authorization وجود ندارند.

**نتیجه:** اجرای DB انجام نشد؛ `NOT VERIFIED`.
